import cors from 'cors';
import dotenv from 'dotenv';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { z } from 'zod';
import {
  requireSuperAdmin,
  verifyFirebaseBearerToken,
  type AuthenticatedRequest,
} from './server/authMiddleware.ts';
import {
  buildErrorReportWorkbook,
  buildSampleTemplateWorkbook,
  formatDateIST,
  parseExcelBuffer,
} from './server/excelEngine.ts';
import {
  authorizeEmployeeStatusChange,
  validateImportBatch,
} from './src/lib/incentiveEngine.ts';
import type {
  Branch,
  Employee,
  ExcelColumnMapping,
  ParsedExcelRow,
  PublishedIncentive,
  RowResolution,
} from './src/types/incentive.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALLOWED_ORIGINS = [
  'https://admin.homfash.com',
  'https://staff.homfash.com',
  'https://localhost',
  'capacitor://localhost',
  'http://localhost:3000',
  process.env.APP_URL || '',
].filter(Boolean);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB safety cap for 512MB Render Free RAM
    files: 1,
  },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.xlsx') {
      cb(new Error('Only .xlsx Excel workbooks are permitted.'));
      return;
    }
    cb(null, true);
  },
});

const errorReportSchema = z.object({
  rows: z.array(
    z.object({
      rowNumber: z.number().int().min(1),
      businessDate: z.string().max(40),
      employeeId: z.string().max(64),
      branchCode: z.string().max(64),
      component1Rupees: z.string().max(32),
      component2Rupees: z.string().max(32),
      component3Rupees: z.string().max(32),
      validationStatus: z.string().max(40),
      errorMessage: z.string().max(400),
    }),
  ).max(5000),
});

const sampleTemplateSchema = z.object({
  businessDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  periodStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  periodEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  rows: z.array(
    z.object({
      employeeId: z.string().max(64),
      employeeName: z.string().max(120).optional(),
      branchName: z.string().max(120),
    }),
  ).max(50).optional(),
});

const validateImportSchema = z.object({
  periodStart: z.string().nullable(),
  periodEnd: z.string().nullable(),
  rawBannerDateText: z.string().max(200).optional(),
  rawTotalRows: z.number().int().min(0),
  skippedBlankRows: z.number().int().min(0),
  skippedSummaryRows: z.number().int().min(0),
  mapping: z.object({
    businessDate: z.string().max(80),
    employeeId: z.string().max(80),
    employeeName: z.string().max(80),
    branchCode: z.string().max(80),
    component1: z.string().max(80),
    component2: z.string().max(80),
    component3: z.string().max(80),
  }),
  rows: z.array(z.any()).max(5000),
  branches: z.array(z.any()).max(500),
  employees: z.array(z.any()).max(5000),
  publishedIncentives: z.array(z.any()).max(20000),
  overrides: z.record(
    z.string(),
    z.object({
      resolution: z.enum(['PUBLISH_NEW', 'SKIP', 'CORRECTION']),
      correctionReason: z.string().max(240),
    }),
  ).optional(),
});

const statusAuthorizeSchema = z.object({
  employeeId: z.string().min(1).max(64),
  currentStatus: z.enum(['ACTIVE', 'INACTIVE']).optional(),
  targetStatus: z.enum(['ACTIVE', 'INACTIVE']),
  reason: z.string().max(240).optional(),
});

export function createApiRouter(authMiddleware = verifyFirebaseBearerToken) {
  const router = express.Router();

  router.get('/health', (_req, res) => {
    res.json({
      service: 'house-of-muktai-incentive-api',
      timezone: 'Asia/Kolkata',
      businessDateToday: formatDateIST(new Date()),
      ok: true,
    });
  });

  router.post(
    '/excel/parse',
    authMiddleware,
    requireSuperAdmin,
    upload.single('file'),
    async (req: AuthenticatedRequest, res) => {
      try {
        if (!req.file) {
          res.status(400).json({ error: 'Please attach a valid .xlsx Excel file.' });
          return;
        }

        // Verify ZIP/XLSX magic header bytes (PK\x03\x04)
        const buf = req.file.buffer;
        if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) {
          res.status(400).json({ error: 'Uploaded file is not a valid .xlsx workbook.' });
          return;
        }

        const requestedSheet = typeof req.body?.sheetName === 'string' ? req.body.sheetName : undefined;
        const parsed = await parseExcelBuffer(buf, req.file.originalname, requestedSheet);
        res.json(parsed);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to parse Excel workbook.';
        res.status(400).json({ error: message });
      }
    },
  );

  // Server-side validation for Daily / Monthly / Custom Period, Overlap & Transfer detection
  router.post(
    '/excel/validate',
    authMiddleware,
    requireSuperAdmin,
    (req: AuthenticatedRequest, res) => {
      try {
        const body = validateImportSchema.parse(req.body ?? {});
        const numericOverrides: Record<
          number,
          { resolution: RowResolution; correctionReason: string }
        > = {};
        if (body.overrides) {
          for (const [k, v] of Object.entries(body.overrides)) {
            const num = Number(k);
            if (Number.isInteger(num)) {
              numericOverrides[num] = v;
            }
          }
        }

        const result = validateImportBatch({
          periodStart: body.periodStart,
          periodEnd: body.periodEnd,
          rawBannerDateText: body.rawBannerDateText,
          rawTotalRows: body.rawTotalRows,
          skippedBlankRows: body.skippedBlankRows,
          skippedSummaryRows: body.skippedSummaryRows,
          mapping: body.mapping as ExcelColumnMapping,
          rows: body.rows as ParsedExcelRow[],
          branches: body.branches as Branch[],
          employees: body.employees as Employee[],
          publishedIncentives: body.publishedIncentives as PublishedIncentive[],
          overrides: numericOverrides,
        });

        res.json(result);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Excel validation failed.';
        res.status(400).json({ error: message });
      }
    },
  );

  // Backend-enforced Super Admin–only Employee Active/Inactive authorization endpoint
  router.post(
    '/admin/employees/authorize-status-change',
    authMiddleware,
    requireSuperAdmin,
    (req: AuthenticatedRequest, res) => {
      try {
        const body = statusAuthorizeSchema.parse(req.body ?? {});
        const actorRole = req.authUser?.role || 'EMPLOYEE';
        const decision = authorizeEmployeeStatusChange({
          actorRole,
          currentStatus: body.currentStatus,
          targetStatus: body.targetStatus,
        });

        if (!decision.allowed) {
          res.status(decision.statusCode).json({ error: decision.error });
          return;
        }

        res.json({
          authorized: true,
          employeeId: body.employeeId,
          targetStatus: body.targetStatus,
          auditAction: decision.auditAction,
          authorizedByEmail: req.authUser?.email || '',
          authorizedAt: new Date().toISOString(),
        });
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Status authorization failed.';
        res.status(400).json({ error: message });
      }
    },
  );

  router.post(
    '/excel/sample-template',
    authMiddleware,
    requireSuperAdmin,
    async (req: AuthenticatedRequest, res) => {
      try {
        const parsed = sampleTemplateSchema.parse(req.body ?? {});
        const startStr = parsed.periodStart || parsed.businessDate || formatDateIST(new Date());
        const endStr = parsed.periodEnd || parsed.businessDate || startStr;
        const baseRows =
          parsed.rows && parsed.rows.length > 0
            ? parsed.rows.map((r, idx) => ({
                branchName: r.branchName.toUpperCase(),
                salesPersonName: r.employeeName || `EMPLOYEE ${r.employeeId}`,
                salesmanNo: r.employeeId,
                component1: 650 + idx * 90,
                component2: 45 + idx * 15,
                component3: 80 + idx * 20,
              }))
            : [
                {
                  branchName: 'BARAMATI MIDC',
                  salesPersonName: 'ANITA POPAT SHINGADE',
                  salesmanNo: '459',
                  component1: 816,
                  component2: 12,
                  component3: 51,
                },
                {
                  branchName: 'BARAMATI MOTIBAG',
                  salesPersonName: 'ASHA ABAJI CHAVAN',
                  salesmanNo: '355',
                  component1: 1713,
                  component2: 341,
                  component3: 125,
                },
                {
                  branchName: 'BEED',
                  salesPersonName: 'AMBRAPALI SHIVAJI VEER',
                  salesmanNo: '2432',
                  component1: 984,
                  component2: 5,
                  component3: 32,
                },
              ];

        const buffer = await buildSampleTemplateWorkbook(startStr, baseRows, endStr);
        res.setHeader(
          'Content-Type',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        );
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="house-of-muktai-incentives-${startStr}-to-${endStr}.xlsx"`,
        );
        res.send(buffer);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to generate sample template.';
        res.status(400).json({ error: message });
      }
    },
  );

  router.post(
    '/excel/error-report',
    authMiddleware,
    requireSuperAdmin,
    async (req: AuthenticatedRequest, res) => {
      try {
        const parsed = errorReportSchema.parse(req.body);
        const buffer = await buildErrorReportWorkbook(parsed.rows);
        res.setHeader(
          'Content-Type',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        );
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="import-validation-report-${formatDateIST(new Date())}.xlsx"`,
        );
        res.send(buffer);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to build error report.';
        res.status(400).json({ error: message });
      }
    },
  );

  return router;
}

export function createExpressApp(authMiddleware = verifyFirebaseBearerToken) {
  const app = express();
  app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
    }),
  );

  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin) {
          callback(null, true);
          return;
        }
        if (
          ALLOWED_ORIGINS.includes(origin) ||
          origin.endsWith('.run.app') ||
          origin.endsWith('.pages.dev')
        ) {
          callback(null, true);
          return;
        }
        callback(new Error('CORS origin not allowed'));
      },
      credentials: false,
      allowedHeaders: ['Content-Type', 'Authorization'],
    }),
  );

  app.use(express.json({ limit: '5mb' }));

  const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many API requests. Please wait a moment and try again.' },
  });

  app.use('/api/v1', apiLimiter);
  app.use('/api/v1', createApiRouter(authMiddleware));

  // Centralized Express error handler (catches Multer and CORS errors cleanly)
  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    res.status(400).json({ error: err.message || 'Unexpected server error.' });
  });

  return app;
}

async function startServer() {
  const app = createExpressApp();
  const PORT = Number(process.env.PORT || 3000);
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`House of Muktai Incentive Server listening on http://0.0.0.0:${PORT}`);
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  startServer();
}
