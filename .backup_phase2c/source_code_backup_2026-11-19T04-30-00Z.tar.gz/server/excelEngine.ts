import crypto from 'crypto';
import ExcelJS from 'exceljs';
import {
  classifyImportPeriod,
  parseDmyToIsoStrict,
} from '../src/lib/incentiveEngine.ts';
import type {
  ExcelColumnMapping,
  ExcelParseResponse,
  ParsedExcelRow,
} from '../src/types/incentive.ts';

const SALES_HEADER_REGEX = /\b(sales\s*amt|sales\s*amount|total\s*sales|net\s*sales|gross\s*sales|revenue|turnover|bill\s*value|invoice\s*amt)\b/i;

const KNOWN_HEADER_SIGNALS = [
  /^name$/i,
  /sales\s*person\s*name/i,
  /salesman\s*no/i,
  /emp(loyee)?[\s_-]*(id|code|name)/i,
  /branch/i,
  /incentive/i,
  /old\s*incentive/i,
];

function extractCellPrimitive(value: ExcelJS.CellValue): string | number | null {
  if (value === null || value === undefined) return null;

  if (value instanceof Date) {
    return formatDateIST(value);
  }

  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
  }

  if (typeof value === 'boolean') {
    return value ? 'TRUE' : 'FALSE';
  }

  if (typeof value === 'object') {
    if ('result' in value && value.result !== undefined && value.result !== null) {
      return extractCellPrimitive(value.result as ExcelJS.CellValue);
    }
    if ('richText' in value && Array.isArray(value.richText)) {
      return value.richText.map((part) => part.text).join('').trim() || null;
    }
    if ('text' in value && typeof value.text === 'string') {
      return value.text.trim() || null;
    }
  }

  return null;
}

export function formatDateIST(date: Date): string {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  return formatter.format(date);
}

function extractBannerMetadata(worksheet: ExcelJS.Worksheet, headerRowNumber: number): {
  reportTitle: string;
  reportDateRangeText: string;
  detectedFromDate: string | null;
  detectedToDate: string | null;
} {
  const bannerTexts: string[] = [];
  for (let r = 1; r < headerRowNumber; r++) {
    const row = worksheet.getRow(r);
    const seenInRow = new Set<string>();
    row.eachCell({ includeEmpty: false }, (cell) => {
      const val = String(extractCellPrimitive(cell.value) ?? '').trim();
      if (val && !seenInRow.has(val)) {
        seenInRow.add(val);
        bannerTexts.push(val);
      }
    });
  }

  let reportTitle = '';
  let reportDateRangeText = '';
  let detectedFromDate: string | null = null;
  let detectedToDate: string | null = null;

  for (const text of bannerTexts) {
    // Match "As On :-01-10-2026 To 31-10-2026", "2026-10-01 to 2026-10-31", etc.
    const rangeMatch = text.match(
      /(\d{1,4}[/-]\d{1,2}[/-]\d{2,4})\s*(?:to|–|—)\s*(\d{1,4}[/-]\d{1,2}[/-]\d{2,4})/i,
    );
    if (rangeMatch) {
      reportDateRangeText = text;
      detectedFromDate = parseDmyToIsoStrict(rangeMatch[1]);
      detectedToDate = parseDmyToIsoStrict(rangeMatch[2]);
      continue;
    }

    // Match hyphen-separated date range with spaces around hyphen: "01-10-2026 - 31-10-2026"
    const spacedHyphenMatch = text.match(
      /(\d{1,4}[/-]\d{1,2}[/-]\d{2,4})\s+-\s+(\d{1,4}[/-]\d{1,2}[/-]\d{2,4})/,
    );
    if (spacedHyphenMatch) {
      reportDateRangeText = text;
      detectedFromDate = parseDmyToIsoStrict(spacedHyphenMatch[1]);
      detectedToDate = parseDmyToIsoStrict(spacedHyphenMatch[2]);
      continue;
    }

    const singleMatch = text.match(/(\d{1,4}[/-]\d{1,2}[/-]\d{2,4})/);
    if (singleMatch && !reportDateRangeText) {
      reportDateRangeText = text;
      detectedFromDate = parseDmyToIsoStrict(singleMatch[1]);
      detectedToDate = detectedFromDate;
      continue;
    }

    if (/as\s*on|period|from|date/i.test(text) && !reportDateRangeText) {
      reportDateRangeText = text;
      continue;
    }

    if (!reportTitle) {
      reportTitle = text;
    }
  }

  return { reportTitle, reportDateRangeText, detectedFromDate, detectedToDate };
}

function detectHeaderRow(worksheet: ExcelJS.Worksheet): number {
  let bestRow = 1;
  let bestScore = -1;
  const maxScan = Math.min(10, worksheet.rowCount);

  for (let r = 1; r <= maxScan; r++) {
    const row = worksheet.getRow(r);
    const labels: string[] = [];
    row.eachCell({ includeEmpty: false }, (cell) => {
      const val = String(extractCellPrimitive(cell.value) ?? '').trim();
      if (val) labels.push(val);
    });
    if (labels.length < 3) continue;

    let score = 0;
    for (const label of labels) {
      if (KNOWN_HEADER_SIGNALS.some((rx) => rx.test(label))) {
        score += 3;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestRow = r;
    }
  }

  return bestRow;
}

function suggestColumnMapping(headers: string[]): ExcelColumnMapping {
  const findHeader = (patterns: RegExp[], exclude: string[] = []): string => {
    for (const pattern of patterns) {
      const match = headers.find((h) => !exclude.includes(h) && pattern.test(h));
      if (match) return match;
    }
    return '';
  };

  const businessDate = findHeader([/business\s*date/i, /^date$/i, /txn\s*date/i, /day/i]);
  const employeeId = findHeader([
    /salesman\s*no/i,
    /salesman\s*id/i,
    /emp(loyee)?[\s_-]*(id|code|no)/i,
    /staff[\s_-]*(id|code|no)/i,
    /login[\s_-]*id/i,
  ]);
  const employeeName = findHeader([
    /sales\s*person\s*name/i,
    /salesman\s*name/i,
    /emp(loyee)?[\s_-]*name/i,
    /staff[\s_-]*name/i,
  ]);
  const branchCode = findHeader(
    [/^name$/i, /branch[\s_-]*(code|id|name)?/i, /store/i, /location/i],
    [employeeName, employeeId].filter(Boolean),
  );

  const used = [businessDate, employeeId, employeeName, branchCode].filter(Boolean);

  // Exact ERP incentive component matching first
  const comp1 = findHeader(
    [/incentive\s*new\s*quantity\s*wise/i, /new\s*quantity/i, /component\s*1/i],
    used,
  );
  const comp2 = findHeader(
    [/old\s*incentive/i, /component\s*2/i],
    [...used, comp1].filter(Boolean),
  );
  const comp3 = findHeader(
    [/incentive\s*[-–]?\s*0\.?50?%/i, /0\.?50?%/i, /component\s*3/i],
    [...used, comp1, comp2].filter(Boolean),
  );

  const remainingCandidates = headers.filter(
    (h) => ![...used, comp1, comp2, comp3].includes(h) && !SALES_HEADER_REGEX.test(h),
  );

  return {
    businessDate,
    employeeId,
    employeeName,
    branchCode,
    component1: comp1 || remainingCandidates[0] || '',
    component2: comp2 || remainingCandidates[1] || '',
    component3: comp3 || remainingCandidates[2] || '',
  };
}

function isBlankMarker(val: string | number | null | undefined): boolean {
  if (val === null || val === undefined) return false;
  const s = String(val).trim().toLowerCase();
  return s === '(blank)' || s === 'blank';
}

function isSummaryRowMarker(val: string | number | null | undefined): boolean {
  if (val === null || val === undefined) return false;
  const s = String(val).trim().toLowerCase();
  return (
    s === 'grand total' ||
    s === 'sub total' ||
    s === 'subtotal' ||
    s === 'total' ||
    s === 'branch total' ||
    /\btotal$/i.test(s)
  );
}

export async function parseExcelBuffer(
  buffer: Buffer,
  fileName: string,
  requestedSheet?: string,
): Promise<ExcelParseResponse> {
  const fileSha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as unknown as ArrayBuffer);

  const availableSheets = workbook.worksheets.map((ws) => ws.name);
  if (availableSheets.length === 0) {
    throw new Error('The uploaded Excel workbook contains no worksheets.');
  }

  const worksheet = requestedSheet
    ? workbook.getWorksheet(requestedSheet) || workbook.worksheets[0]
    : workbook.worksheets[0];

  const headerRowNumber = detectHeaderRow(worksheet);
  const banner = extractBannerMetadata(worksheet, headerRowNumber);
  const periodClassification = classifyImportPeriod(
    banner.detectedFromDate,
    banner.detectedToDate,
    banner.reportDateRangeText,
  );
  const headerRow = worksheet.getRow(headerRowNumber);

  const rawHeaders: { colIndex: number; name: string }[] = [];
  const excludedSalesColumns: string[] = [];

  headerRow.eachCell({ includeEmpty: false }, (cell, colNumber) => {
    const label = String(extractCellPrimitive(cell.value) ?? '').trim();
    if (!label) return;
    if (SALES_HEADER_REGEX.test(label)) {
      excludedSalesColumns.push(label);
      return;
    }
    rawHeaders.push({ colIndex: colNumber, name: label });
  });

  if (rawHeaders.length === 0) {
    throw new Error(`Row ${headerRowNumber} does not contain recognizable column headers.`);
  }

  const headers = rawHeaders.map((h) => h.name);
  const suggestedMapping = suggestColumnMapping(headers);
  const rows: ParsedExcelRow[] = [];
  let rawTotalRows = 0;
  let skippedBlankRows = 0;
  let skippedSummaryRows = 0;

  for (let rowIdx = headerRowNumber + 1; rowIdx <= worksheet.rowCount; rowIdx++) {
    const row = worksheet.getRow(rowIdx);
    const record: Record<string, string | number | null> = {};
    let hasAnyValue = false;

    for (const h of rawHeaders) {
      const val = extractCellPrimitive(row.getCell(h.colIndex).value);
      record[h.name] = val;
      if (val !== null && String(val).trim() !== '') {
        hasAnyValue = true;
      }
    }

    if (!hasAnyValue) continue;
    rawTotalRows += 1;

    const empIdCell = suggestedMapping.employeeId ? record[suggestedMapping.employeeId] : null;
    const empNameCell = suggestedMapping.employeeName ? record[suggestedMapping.employeeName] : null;
    const branchCell = suggestedMapping.branchCode ? record[suggestedMapping.branchCode] : null;

    if (
      isSummaryRowMarker(branchCell) ||
      isSummaryRowMarker(empNameCell) ||
      isSummaryRowMarker(empIdCell)
    ) {
      skippedSummaryRows += 1;
      continue;
    }

    if (
      isBlankMarker(empIdCell) ||
      isBlankMarker(empNameCell) ||
      isBlankMarker(branchCell)
    ) {
      skippedBlankRows += 1;
      continue;
    }

    rows.push({
      rowNumber: rowIdx,
      raw: record,
    });
  }

  return {
    fileName,
    fileSha256,
    sheetName: worksheet.name,
    availableSheets,
    headerRowNumber,
    reportTitle: banner.reportTitle,
    reportDateRangeText: banner.reportDateRangeText,
    importType: periodClassification.importType,
    periodStart: periodClassification.periodStart,
    periodEnd: periodClassification.periodEnd,
    detectedFromDate: banner.detectedFromDate,
    detectedToDate: banner.detectedToDate,
    dateValidationError: periodClassification.errorMessage,
    rawTotalRows,
    skippedBlankRows,
    skippedSummaryRows,
    headers,
    excludedSalesColumns,
    suggestedMapping,
    totalRows: rows.length,
    rows,
  };
}

function isoToDmy(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}-${m}-${y}`;
}

export async function buildSampleTemplateWorkbook(
  periodStartIso: string,
  sampleRows: Array<{
    branchName: string;
    salesPersonName: string;
    salesmanNo: string;
    component1: number;
    component2: number;
    component3: number;
  }>,
  periodEndIso?: string,
  bannerOverride?: string,
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'House of Muktai Incentive System';
  workbook.created = new Date();

  const startDmy = isoToDmy(periodStartIso);
  const endDmy = isoToDmy(periodEndIso || periodStartIso);

  const sheet = workbook.addWorksheet('Final Report');

  // Row 1: Exact House of Muktai ERP Banner Format
  sheet.mergeCells('A1:B1');
  sheet.getCell('A1').value = 'Final Report incentive All Branches';
  sheet.getCell('A1').font = { bold: true, size: 11 };
  sheet.getCell('A1').alignment = { horizontal: 'center' };
  sheet.getCell('A1').fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFFCD5B4' },
  };

  sheet.mergeCells('C1:F1');
  sheet.getCell('C1').value =
    bannerOverride !== undefined ? bannerOverride : `As On :-${startDmy} To ${endDmy}`;
  sheet.getCell('C1').font = { bold: true, size: 11 };
  sheet.getCell('C1').alignment = { horizontal: 'center' };

  // Row 2: Exact ERP Headers
  const headerRow = sheet.addRow([
    'NAME',
    'Sales Person Name',
    'Salesman No',
    'Incentive New Quantity Wise',
    'Old Incentive',
    'Incentive - 0.50%',
  ]);
  headerRow.font = { bold: true };
  sheet.columns = [
    { width: 22 },
    { width: 30 },
    { width: 14 },
    { width: 28 },
    { width: 16 },
    { width: 18 },
  ];

  for (const row of sampleRows) {
    sheet.addRow([
      row.branchName,
      row.salesPersonName,
      Number.isFinite(Number(row.salesmanNo)) && row.salesmanNo.trim() !== ''
        ? Number(row.salesmanNo)
        : row.salesmanNo,
      row.component1,
      row.component2,
      row.component3,
    ]);
  }

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}

export async function buildErrorReportWorkbook(
  rows: Array<{
    rowNumber: number;
    businessDate: string;
    employeeId: string;
    branchCode: string;
    component1Rupees: string;
    component2Rupees: string;
    component3Rupees: string;
    validationStatus: string;
    errorMessage: string;
  }>,
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'House of Muktai Incentive System';
  workbook.created = new Date();

  const sheet = workbook.addWorksheet('Validation Error Report');
  sheet.columns = [
    { header: 'Row #', key: 'rowNumber', width: 10 },
    { header: 'Period / Date', key: 'businessDate', width: 24 },
    { header: 'Salesman No', key: 'employeeId', width: 16 },
    { header: 'Branch (NAME)', key: 'branchCode', width: 22 },
    { header: 'Incentive New Quantity Wise', key: 'component1Rupees', width: 26 },
    { header: 'Old Incentive', key: 'component2Rupees', width: 16 },
    { header: 'Incentive - 0.50%', key: 'component3Rupees', width: 18 },
    { header: 'Status', key: 'validationStatus', width: 22 },
    { header: 'Issue / Resolution Notes', key: 'errorMessage', width: 52 },
  ];

  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF0F172A' },
  };

  for (const row of rows) {
    sheet.addRow(row);
  }

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}
