import { createRemoteJWKSet, jwtVerify } from 'jose';
import type { NextFunction, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import type { UserRole } from '../src/types/incentive.ts';

export interface VerifiedAuthUser {
  uid: string;
  email: string;
  emailVerified: boolean;
  role: UserRole;
  isSuperAdmin: boolean;
}

export interface AuthenticatedRequest extends Request {
  authUser?: VerifiedAuthUser;
}

const BOOTSTRAPPED_ADMIN_EMAIL = 'uhvishal41@gmail.com';

function loadFirebaseProjectId(): string {
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const parsed = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      if (parsed.projectId) return String(parsed.projectId);
    }
  } catch {
    // Fallback to env variable
  }
  return process.env.FIREBASE_PROJECT_ID || '';
}

const FIREBASE_JWKS = createRemoteJWKSet(
  new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'),
);

export function resolveRoleFromClaims(params: {
  email: string;
  emailVerified: boolean;
  claimRole?: unknown;
}): UserRole {
  if (
    params.emailVerified &&
    params.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase()
  ) {
    return 'SUPER_ADMIN';
  }
  if (params.claimRole === 'SUPER_ADMIN' && params.emailVerified) {
    return 'SUPER_ADMIN';
  }
  if (params.claimRole === 'BRANCH_MANAGER') {
    return 'BRANCH_MANAGER';
  }
  return 'EMPLOYEE';
}

export async function verifyFirebaseBearerToken(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing Bearer authentication token.' });
      return;
    }

    const token = header.slice('Bearer '.length).trim();
    const projectId = loadFirebaseProjectId();
    if (!projectId) {
      res.status(500).json({ error: 'Firebase project configuration is missing on server.' });
      return;
    }

    const { payload } = await jwtVerify(token, FIREBASE_JWKS, {
      issuer: `https://securetoken.google.com/${projectId}`,
      audience: projectId,
    });

    const uid = typeof payload.sub === 'string' ? payload.sub : '';
    const email = typeof payload.email === 'string' ? payload.email : '';
    const emailVerified = payload.email_verified === true;

    if (!uid) {
      res.status(401).json({ error: 'Invalid authentication token subject.' });
      return;
    }

    const role = resolveRoleFromClaims({
      email,
      emailVerified,
      claimRole: payload.role,
    });

    req.authUser = {
      uid,
      email,
      emailVerified,
      role,
      isSuperAdmin: role === 'SUPER_ADMIN',
    };

    next();
  } catch {
    res.status(401).json({ error: 'Authentication token is invalid or expired.' });
  }
}

export function createRoleGuard(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.authUser) {
      res.status(401).json({ error: 'Authentication is required.' });
      return;
    }
    if (!allowedRoles.includes(req.authUser.role)) {
      res.status(403).json({
        error: `Forbidden: Role "${req.authUser.role}" is not permitted to perform this operation. Super Admin authorization is required.`,
      });
      return;
    }
    next();
  };
}

export const requireSuperAdmin = createRoleGuard(['SUPER_ADMIN']);
