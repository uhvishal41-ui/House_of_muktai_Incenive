# Security Specification — House of Muktai Employee Incentive Management System

## 1. Core Data Invariants
1. **Strict Admin Gate:** Only verified Super Admins (`request.auth.token.email_verified == true` and matching bootstrapped admin email or `/admins/{uid}`) may manage branches, create/deactivate employees, upload/validate/approve/publish/reject Excel batches, write incentives, or view audit logs.
2. **Zero Unpublished Leakage:** `import_batches`, `import_batch_rows`, `incentive_versions`, and `audit_logs` are completely unreadable and unwritable by employees.
3. **Anti-IDOR Employee Isolation:** An employee can only `get` or `list` documents in `published_incentives`, `monthly_summaries`, `employees`, and `notifications` where `resource.data.authUid == request.auth.uid` (and `resource.data.status == 'PUBLISHED'` for incentives). No `get()` lookups are used inside `allow list`.
4. **No Sales Figures:** `published_incentives` enforces strict key allowlisting (`hasOnly`) that prohibits any `salesAmount` or shadow fields from being stored.
5. **Strict Calculation Integrity:** `published_incentives` requires `totalPaise == component1Paise + component2Paise + component3Paise` and non-negative component amounts.
6. **Immutable History:** `audit_logs` and `incentive_versions` forbid all `update` and `delete` operations.
7. **Permitted Employee Profile Edits Only:** Employees updating their own `/employees/{employeeId}` record may only modify `['phone', 'address', 'emergencyContact', 'mustChangePassword', 'updatedAt']` and cannot escalate `role`, `status`, `branchId`, `loginId`, or `authUid`.

## 2. The "Dirty Dozen" Adversarial Payloads (Must All Return PERMISSION_DENIED)
1. **Unauthenticated Read:** Anonymous client attempting `get` or `list` on `/published_incentives`.
2. **Cross-Employee IDOR Read:** Employee A (`uid: emp_a`) attempting `get` on Employee B's `/published_incentives/2026-11-18_EMP002`.
3. **Unfiltered List Scrape:** Employee A attempting `list` on `/published_incentives` without matching `where('authUid', '==', 'emp_a')`.
4. **Unpublished Batch Snooping:** Employee attempting `get` or `list` on `/import_batches` or `/import_batch_rows`.
5. **Privilege Escalation on Profile Update:** Employee updating `/employees/EMP001` with `{ "role": "SUPER_ADMIN" }` or `{ "status": "ACTIVE", "branchId": "BR02" }`.
6. **Shadow Field / Sales Data Injection:** Write to `/published_incentives` containing an extra field `{ "salesAmount": 500000 }` or `{ "isVerified": true }`.
7. **Tampered Total Math:** Write to `/published_incentives` where `totalPaise != component1Paise + component2Paise + component3Paise`.
8. **Audit Log Tampering:** Any user (including Admin) attempting `update` or `delete` on `/audit_logs/{logId}`.
9. **Correction History Deletion:** Any user attempting `update` or `delete` on `/incentive_versions/{versionId}`.
10. **Email Spoofing Attack:** Unverified auth token (`email_verified: false`) matching admin email attempting to write `/branches/BR01`.
11. **ID Poisoning Attack:** Request targeting a document ID containing invalid characters or exceeding 128 chars (`../admin/../../`).
12. **Notification Hijack:** Employee A attempting to mark Employee B's notification as read or inject unauthorized keys into `/notifications/{id}`.
