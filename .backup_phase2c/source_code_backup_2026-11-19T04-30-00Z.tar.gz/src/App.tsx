import React from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LoginView } from './components/LoginView';
import { AdminShell } from './components/admin/AdminShell';
import { EmployeePortal } from './components/staff/EmployeePortal';
import { AuthProvider, useAuth } from './context/AuthContext';

function AppRouter() {
  const { user, loading, isSuperAdmin } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center p-6">
        <div className="text-center space-y-2">
          <div className="w-6 h-6 border-2 border-rose-900 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-medium text-slate-500">
            Connecting to House of Muktai Incentive Platform...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  if (isSuperAdmin) {
    return <AdminShell />;
  }

  return <EmployeePortal />;
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </ErrorBoundary>
  );
}
