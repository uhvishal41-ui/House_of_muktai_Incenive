import {
  collection,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import {
  auth,
  db,
  getSecondaryProvisioningAuth,
  handleFirestoreError,
  loginIdToAuthEmail,
  OperationType,
} from '../lib/firebase';
import { formatShortDate, generateRecordId, sanitizeId } from '../lib/format';
import {
  applyPublishedCorrection,
  buildMonthlySummaryDocument,
  detectPeriodOverlapsForEmployee,
  formatImportTypeLabel,
  getIncentiveRecordKey,
} from '../lib/incentiveEngine';
import type {
  AuditLog,
  Branch,
  ComponentLabels,
  Employee,
  EmployeeNotification,
  ImportBatch,
  ImportBatchRow,
  ImportType,
  IncentiveVersion,
  MonthlySummary,
  PublishedIncentive,
} from '../types/incentive';

const DEFAULT_12_BRANCHES: Array<{ code: string; name: string; city: string; manager: string }> = [
  { code: 'HOM-01', name: 'House of Muktai — Flagship', city: 'Mumbai', manager: '' },
  { code: 'HOM-02', name: 'House of Muktai — Bandra', city: 'Mumbai', manager: '' },
  { code: 'HOM-03', name: 'House of Muktai — Thane', city: 'Thane', manager: '' },
  { code: 'HOM-04', name: 'House of Muktai — Navi Mumbai', city: 'Navi Mumbai', manager: '' },
  { code: 'HOM-05', name: 'House of Muktai — Pune FC Road', city: 'Pune', manager: '' },
  { code: 'HOM-06', name: 'House of Muktai — Pune Kothrud', city: 'Pune', manager: '' },
  { code: 'HOM-07', name: 'House of Muktai — Nashik', city: 'Nashik', manager: '' },
  { code: 'HOM-08', name: 'House of Muktai — Nagpur', city: 'Nagpur', manager: '' },
  { code: 'HOM-09', name: 'House of Muktai — Surat', city: 'Surat', manager: '' },
  { code: 'HOM-10', name: 'House of Muktai — Ahmedabad', city: 'Ahmedabad', manager: '' },
  { code: 'HOM-11', name: 'House of Muktai — Indore', city: 'Indore', manager: '' },
  { code: 'HOM-12', name: 'House of Muktai — Kolhapur', city: 'Kolhapur', manager: '' },
];

export async function recordAuditLog(params: {
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  actorRole?: string;
}) {
  const user = auth.currentUser;
  if (!user) return;
  const logId = generateRecordId('LOG');
  const logEntry: AuditLog = {
    logId,
    action: params.action.slice(0, 80),
    actorUid: user.uid,
    actorEmail: (user.email || 'unknown').slice(0, 180),
    actorRole: (params.actorRole || 'SUPER_ADMIN').slice(0, 40),
    targetType: params.targetType.slice(0, 64),
    targetId: params.targetId.slice(0, 128),
    summary: params.summary.slice(0, 400),
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'audit_logs', logId), logEntry);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `audit_logs/${logId}`);
  }
}

// --- BRANCH MASTER ---
export async function listBranches(): Promise<Branch[]> {
  try {
    const snap = await getDocs(query(collection(db, 'branches'), orderBy('branchCode', 'asc')));
    return snap.docs.map((d) => d.data() as Branch);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'branches');
  }
}

export async function saveBranch(input: {
  branchId?: string;
  branchCode: string;
  branchName: string;
  city: string;
  managerName?: string;
  active: boolean;
  existingCreatedAt?: string;
}): Promise<Branch> {
  const now = new Date().toISOString();
  const cleanCode = sanitizeId(input.branchCode).slice(0, 24);
  const branchId = input.branchId || cleanCode;
  const payload: Branch = {
    branchId,
    branchCode: cleanCode,
    branchName: input.branchName.trim().slice(0, 120),
    city: input.city.trim().slice(0, 80),
    active: input.active,
    createdAt: input.existingCreatedAt || now,
    updatedAt: now,
    ...(input.managerName?.trim() ? { managerName: input.managerName.trim().slice(0, 120) } : {}),
  };

  try {
    await setDoc(doc(db, 'branches', branchId), payload);
    await recordAuditLog({
      action: input.existingCreatedAt ? 'BRANCH_UPDATED' : 'BRANCH_CREATED',
      targetType: 'branch',
      targetId: branchId,
      summary: `${input.existingCreatedAt ? 'Updated' : 'Created'} branch ${payload.branchCode} (${payload.branchName})`,
    });
    return payload;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `branches/${branchId}`);
  }
}

export async function initializeDefault12Branches(): Promise<number> {
  const now = new Date().toISOString();
  try {
    const batch = writeBatch(db);
    for (const b of DEFAULT_12_BRANCHES) {
      const branchId = sanitizeId(b.code);
      const record: Branch = {
        branchId,
        branchCode: branchId,
        branchName: b.name,
        city: b.city,
        active: true,
        createdAt: now,
        updatedAt: now,
      };
      batch.set(doc(db, 'branches', branchId), record);
    }
    await batch.commit();
    await recordAuditLog({
      action: 'BRANCHES_INITIALIZED',
      targetType: 'branch',
      targetId: 'BATCH_12',
      summary: 'Initialized 12 House of Muktai retail branch master records',
    });
    return DEFAULT_12_BRANCHES.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'branches');
  }
}

// --- EMPLOYEE MASTER ---
export async function listEmployees(): Promise<Employee[]> {
  try {
    const snap = await getDocs(query(collection(db, 'employees'), orderBy('employeeId', 'asc')));
    return snap.docs.map((d) => d.data() as Employee);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'employees');
  }
}

export async function provisionEmployeeCredentials(
  loginId: string,
  initialPassword: string,
): Promise<{ uid: string; status: 'CREATED' | 'AUTH_PROVIDER_DISABLED' | 'ALREADY_EXISTS'; message: string }> {
  const authEmail = loginIdToAuthEmail(loginId);
  const secondaryAuth = getSecondaryProvisioningAuth();
  try {
    const cred = await createUserWithEmailAndPassword(secondaryAuth, authEmail, initialPassword);
    const uid = cred.user.uid;
    await signOut(secondaryAuth);
    return {
      uid,
      status: 'CREATED',
      message: `Login credentials provisioned for ${loginId}.`,
    };
  } catch (err: unknown) {
    const code = (err as { code?: string })?.code || '';
    if (code === 'auth/operation-not-allowed') {
      return {
        uid: '',
        status: 'AUTH_PROVIDER_DISABLED',
        message:
          'Employee saved in Firestore. To activate Login ID + Password sign-in, enable "Email/Password" in Firebase Console -> Authentication -> Sign-in method.',
      };
    }
    if (code === 'auth/email-already-in-use') {
      return {
        uid: '',
        status: 'ALREADY_EXISTS',
        message: `Auth account for ${loginId} already exists in Firebase Authentication.`,
      };
    }
    throw err;
  }
}

export async function saveEmployee(input: {
  employeeId: string;
  loginId: string;
  fullName: string;
  branchId: string;
  branchName: string;
  designation: string;
  phone?: string;
  address?: string;
  emergencyContact?: string;
  linkedGoogleEmail?: string;
  role: 'EMPLOYEE' | 'BRANCH_MANAGER';
  status: 'ACTIVE' | 'INACTIVE';
  mustChangePassword: boolean;
  initialPassword?: string;
  existing?: Employee | null;
}): Promise<{ employee: Employee; provisioningNote: string }> {
  const now = new Date().toISOString();
  const employeeId = sanitizeId(input.employeeId).slice(0, 64);
  const loginId = sanitizeId(input.loginId).slice(0, 40);
  const authEmail = loginIdToAuthEmail(loginId);

  let authUid = input.existing?.authUid || '';
  let credentialsProvisioned = input.existing?.credentialsProvisioned || false;
  let provisioningNote = '';

  if (input.initialPassword && input.initialPassword.trim().length >= 8 && !credentialsProvisioned) {
    const prov = await provisionEmployeeCredentials(loginId, input.initialPassword.trim());
    if (prov.status === 'CREATED') {
      authUid = prov.uid;
      credentialsProvisioned = true;
    }
    provisioningNote = prov.message;
  }

  const record: Employee = {
    employeeId,
    loginId,
    authEmail,
    fullName: input.fullName.trim().slice(0, 120),
    branchId: input.branchId,
    branchName: input.branchName.trim().slice(0, 120),
    designation: input.designation.trim().slice(0, 80),
    role: input.role,
    status: input.status,
    mustChangePassword: input.mustChangePassword,
    credentialsProvisioned,
    createdAt: input.existing?.createdAt || now,
    updatedAt: now,
    ...(authUid ? { authUid } : {}),
    ...(input.linkedGoogleEmail?.trim()
      ? { linkedGoogleEmail: input.linkedGoogleEmail.trim().toLowerCase().slice(0, 180) }
      : {}),
    ...(input.phone?.trim() ? { phone: input.phone.trim().slice(0, 24) } : {}),
    ...(input.address?.trim() ? { address: input.address.trim().slice(0, 240) } : {}),
    ...(input.emergencyContact?.trim()
      ? { emergencyContact: input.emergencyContact.trim().slice(0, 120) }
      : {}),
  };

  try {
    await setDoc(doc(db, 'employees', employeeId), record);
    await recordAuditLog({
      action: input.existing ? 'EMPLOYEE_UPDATED' : 'EMPLOYEE_CREATED',
      targetType: 'employee',
      targetId: employeeId,
      summary: `${input.existing ? 'Updated' : 'Created'} employee ${employeeId} (${record.fullName}, Login ID: ${loginId}, Branch: ${record.branchName}, Status: ${record.status})`,
    });
    return { employee: record, provisioningNote };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `employees/${employeeId}`);
  }
}

/**
 * Super Admin ONLY: Activates, deactivates, or reactivates an employee.
 * Verified on both Backend API (Bearer + requireSuperAdmin) and Firestore Security Rules (isSuperAdmin).
 * NEVER deletes employee record, historical incentives, or audit logs.
 */
export async function updateEmployeeStatus(params: {
  employee: Employee;
  targetStatus: 'ACTIVE' | 'INACTIVE';
  reason?: string;
}): Promise<{ auditAction: string }> {
  const user = auth.currentUser;
  if (!user) throw new Error('Super Admin authentication is required.');

  const token = await user.getIdToken();
  const resp = await fetch('/api/v1/admin/employees/authorize-status-change', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      employeeId: params.employee.employeeId,
      currentStatus: params.employee.status,
      targetStatus: params.targetStatus,
      reason: params.reason?.trim() || undefined,
    }),
  });

  const authDecision = await resp.json().catch(() => ({ error: 'Authorization failed.' }));
  if (!resp.ok) {
    throw new Error(authDecision.error || 'Only Super Admin can change employee Active/Inactive status.');
  }

  const now = new Date().toISOString();
  const auditAction: string =
    authDecision.auditAction ||
    (params.targetStatus === 'INACTIVE'
      ? 'EMPLOYEE_DEACTIVATED'
      : params.employee.status === 'INACTIVE'
        ? 'EMPLOYEE_REACTIVATED'
        : 'EMPLOYEE_ACTIVATED');

  try {
    await updateDoc(doc(db, 'employees', params.employee.employeeId), {
      status: params.targetStatus,
      updatedAt: now,
    });

    const reasonText = params.reason?.trim() ? ` Reason: ${params.reason.trim()}` : '';
    await recordAuditLog({
      action: auditAction,
      targetType: 'employee',
      targetId: params.employee.employeeId,
      summary: `Super Admin changed ${params.employee.employeeId} (${params.employee.fullName}) from ${params.employee.status} to ${params.targetStatus}. Historical incentives & audit logs preserved.${reasonText}`,
    });

    return { auditAction };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `employees/${params.employee.employeeId}`);
  }
}

/**
 * Super Admin ONLY: Explicitly approves a branch transfer detected during Excel import.
 * Excel import NEVER silently overwrites an employee's branch.
 */
export async function approveEmployeeBranchTransfer(params: {
  employee: Employee;
  newBranchId: string;
  newBranchName: string;
  reason?: string;
}): Promise<void> {
  const now = new Date().toISOString();
  try {
    await updateDoc(doc(db, 'employees', params.employee.employeeId), {
      branchId: params.newBranchId,
      branchName: params.newBranchName.trim().slice(0, 120),
      updatedAt: now,
    });
    await recordAuditLog({
      action: 'EMPLOYEE_BRANCH_TRANSFERRED',
      targetType: 'employee',
      targetId: params.employee.employeeId,
      summary: `Super Admin approved branch transfer for ${params.employee.employeeId} (${params.employee.fullName}): ${params.employee.branchName} -> ${params.newBranchName}.${params.reason ? ` Note: ${params.reason}` : ''}`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `employees/${params.employee.employeeId}`);
  }
}

export async function updateOwnEmployeeProfile(
  employeeId: string,
  updates: { phone: string; address: string; emergencyContact: string; mustChangePassword?: boolean },
): Promise<void> {
  const payload: Record<string, string | boolean> = {
    phone: updates.phone.trim().slice(0, 24),
    address: updates.address.trim().slice(0, 240),
    emergencyContact: updates.emergencyContact.trim().slice(0, 120),
    updatedAt: new Date().toISOString(),
  };
  if (typeof updates.mustChangePassword === 'boolean') {
    payload.mustChangePassword = updates.mustChangePassword;
  }

  try {
    await updateDoc(doc(db, 'employees', employeeId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `employees/${employeeId}`);
  }
}

function toCleanTitleCase(raw: string): string {
  return raw
    .trim()
    .replace(/\s+/g, ' ')
    .split(' ')
    .map((word) => (word.length > 0 ? word[0].toUpperCase() + word.slice(1).toLowerCase() : ''))
    .join(' ');
}

/**
 * Super Admin–controlled ERP master registration:
 * - Registers ONLY missing branches and explicitly reviewed new employee candidates.
 * - NEVER auto-sets SMPL or any employee to INACTIVE without explicit Super Admin selection (`initialStatus`).
 * - NEVER overwrites existing employees' status or branch.
 */
export async function syncMastersFromErpRows(params: {
  missingBranches: string[];
  missingEmployees: Array<{
    salesmanNo: string;
    salesPersonName: string;
    erpBranchName: string;
    isSmplCandidate: boolean;
    initialStatus: 'ACTIVE' | 'INACTIVE';
  }>;
  existingBranches: Branch[];
  existingEmployees?: Employee[];
}): Promise<{ branchesCreated: number; employeesCreated: number }> {
  const now = new Date().toISOString();
  const branchLookup: Record<string, Branch> = {};
  for (const b of params.existingBranches) {
    branchLookup[b.branchName.trim().toUpperCase()] = b;
    branchLookup[b.branchCode.trim().toUpperCase()] = b;
  }

  const existingEmpSet = new Set<string>(
    (params.existingEmployees || []).map((e) => sanitizeId(e.employeeId)),
  );

  const ops: Array<{ ref: ReturnType<typeof doc>; data: Branch | Employee }> = [];
  let branchesCreated = 0;

  for (const rawBranch of params.missingBranches) {
    const cleanName = rawBranch.trim().replace(/\s+/g, ' ').toUpperCase();
    if (!cleanName || branchLookup[cleanName]) continue;
    const branchCode = sanitizeId(cleanName).slice(0, 24);
    const branchDoc: Branch = {
      branchId: branchCode,
      branchCode,
      branchName: cleanName,
      city: toCleanTitleCase(cleanName.split(' ')[0] || cleanName).slice(0, 80),
      active: true,
      createdAt: now,
      updatedAt: now,
    };
    branchLookup[cleanName] = branchDoc;
    branchLookup[branchCode] = branchDoc;
    ops.push({ ref: doc(db, 'branches', branchCode), data: branchDoc });
    branchesCreated += 1;
  }

  let employeesCreated = 0;
  const seenEmpIds = new Set<string>();

  for (const emp of params.missingEmployees) {
    const employeeId = sanitizeId(emp.salesmanNo).slice(0, 64);
    // Strict safeguard: NEVER touch existing employee records
    if (!employeeId || seenEmpIds.has(employeeId) || existingEmpSet.has(employeeId)) continue;
    seenEmpIds.add(employeeId);

    const branchKey = emp.erpBranchName.trim().replace(/\s+/g, ' ').toUpperCase();
    const branch = branchLookup[branchKey] || branchLookup[sanitizeId(branchKey).slice(0, 24)];
    if (!branch) continue;

    const loginId = `HOM${employeeId}`.slice(0, 40);
    const empDoc: Employee = {
      employeeId,
      loginId,
      authEmail: loginIdToAuthEmail(loginId),
      fullName: toCleanTitleCase(emp.salesPersonName || `Salesman ${employeeId}`).slice(0, 120),
      branchId: branch.branchId,
      branchName: branch.branchName,
      designation: emp.isSmplCandidate ? 'Sales Executive (SMPL)' : 'Sales Executive',
      role: 'EMPLOYEE',
      // Explicitly controlled by Super Admin selection — NEVER auto-assigned based on SMPL naming
      status: emp.initialStatus,
      mustChangePassword: true,
      credentialsProvisioned: false,
      createdAt: now,
      updatedAt: now,
    };
    ops.push({ ref: doc(db, 'employees', employeeId), data: empDoc });
    employeesCreated += 1;
  }

  try {
    // Chunk writes at 400 operations to stay well below Firestore's 500-op batch ceiling
    for (let i = 0; i < ops.length; i += 400) {
      const wb = writeBatch(db);
      for (const op of ops.slice(i, i + 400)) {
        wb.set(op.ref, op.data);
      }
      await wb.commit();
    }

    await recordAuditLog({
      action: 'ERP_MASTERS_REGISTERED_BY_ADMIN',
      targetType: 'master_sync',
      targetId: `SYNC_${Date.now()}`,
      summary: `Super Admin registered ${branchesCreated} new branches and ${employeesCreated} new employee candidates (explicit admin-selected status per employee).`,
    });

    return { branchesCreated, employeesCreated };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'employees');
  }
}

// --- PUBLISHED INCENTIVES & MONTHLY SUMMARIES ---
export async function listAllPublishedIncentives(): Promise<PublishedIncentive[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'published_incentives'), orderBy('businessDate', 'desc')),
    );
    return snap.docs.map((d) => d.data() as PublishedIncentive);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'published_incentives');
  }
}

export async function listAllMonthlySummaries(): Promise<MonthlySummary[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'monthly_summaries'), orderBy('monthKey', 'desc')),
    );
    return snap.docs.map((d) => d.data() as MonthlySummary);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'monthly_summaries');
  }
}

export async function listImportBatches(): Promise<ImportBatch[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'import_batches'), orderBy('createdAt', 'desc')),
    );
    return snap.docs.map((d) => d.data() as ImportBatch);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'import_batches');
  }
}

export async function listBatchRows(batchId: string): Promise<ImportBatchRow[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'import_batch_rows'), where('batchId', '==', batchId)),
    );
    return snap.docs
      .map((d) => d.data() as ImportBatchRow)
      .sort((a, b) => a.rowNumber - b.rowNumber);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'import_batch_rows');
  }
}

export async function listIncentiveVersions(): Promise<IncentiveVersion[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'incentive_versions'), orderBy('archivedAt', 'desc')),
    );
    return snap.docs.map((d) => d.data() as IncentiveVersion);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'incentive_versions');
  }
}

export async function listAuditLogs(): Promise<AuditLog[]> {
  try {
    const snap = await getDocs(query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc')));
    return snap.docs.map((d) => d.data() as AuditLog);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'audit_logs');
  }
}

// --- STAGING, APPROVAL, REJECTION & ATOMIC PUBLISHING WORKFLOW ---
export async function stageValidatedBatch(params: {
  fileName: string;
  fileSha256: string;
  importType: ImportType;
  periodStart: string;
  periodEnd: string;
  businessDate: string;
  skippedBlankRows: number;
  skippedSummaryRows: number;
  componentLabels: ComponentLabels;
  rows: Omit<ImportBatchRow, 'rowId' | 'batchId' | 'createdAt'>[];
}): Promise<{ batch: ImportBatch; rows: ImportBatchRow[] }> {
  const user = auth.currentUser;
  if (!user) throw new Error('Super Admin authentication is required.');

  const overlapRowsCount = params.rows.filter((r) => r.validationStatus === 'PERIOD_OVERLAP').length;
  if (overlapRowsCount > 0) {
    throw new Error(
      `Cannot stage batch: ${overlapRowsCount} row(s) have unresolved period overlap conflicts with existing published records.`,
    );
  }

  const now = new Date().toISOString();
  const batchId = generateRecordId('BATCH');

  const stagedRows: ImportBatchRow[] = params.rows.map((r) => ({
    ...r,
    rowId: `${batchId}_R${r.rowNumber}`,
    batchId,
    createdAt: now,
  }));

  const validRows = stagedRows.filter((r) => r.validationStatus === 'VALID').length;
  const errorRows = stagedRows.filter((r) => r.validationStatus === 'ERROR').length;
  const duplicateRows = stagedRows.filter(
    (r) => r.validationStatus === 'DUPLICATE_IN_FILE' || r.validationStatus === 'EXISTS_PUBLISHED',
  ).length;
  const correctionRows = stagedRows.filter((r) => r.resolution === 'CORRECTION').length;
  const branchTransferRows = stagedRows.filter(
    (r) => r.validationStatus === 'BRANCH_TRANSFER',
  ).length;
  const totalIncentivePaise = stagedRows
    .filter((r) => r.resolution === 'PUBLISH_NEW' || r.resolution === 'CORRECTION')
    .reduce((acc, r) => acc + r.totalPaise, 0);

  const batchDoc: ImportBatch = {
    batchId,
    fileName: params.fileName.slice(0, 180),
    fileSha256: params.fileSha256.slice(0, 128),
    importType: params.importType,
    periodStart: params.periodStart,
    periodEnd: params.periodEnd,
    businessDate: params.businessDate.slice(0, 20),
    status: 'VALIDATED',
    totalRows: stagedRows.length,
    validRows,
    errorRows,
    duplicateRows,
    correctionRows,
    overlapRows: overlapRowsCount,
    branchTransferRows,
    skippedBlankRows: params.skippedBlankRows,
    skippedSummaryRows: params.skippedSummaryRows,
    totalIncentivePaise,
    componentLabels: params.componentLabels,
    uploadedByUid: user.uid,
    uploadedByEmail: (user.email || 'admin').slice(0, 180),
    createdAt: now,
    updatedAt: now,
  };

  try {
    const stageOps: Array<() => { ref: ReturnType<typeof doc>; data: ImportBatch | ImportBatchRow }> = [
      () => ({ ref: doc(db, 'import_batches', batchId), data: batchDoc }),
      ...stagedRows.map((row) => () => ({ ref: doc(db, 'import_batch_rows', row.rowId), data: row })),
    ];

    for (let i = 0; i < stageOps.length; i += 400) {
      const wb = writeBatch(db);
      for (const buildOp of stageOps.slice(i, i + 400)) {
        const op = buildOp();
        wb.set(op.ref, op.data);
      }
      await wb.commit();
    }

    await recordAuditLog({
      action: 'IMPORT_BATCH_STAGED',
      targetType: 'import_batch',
      targetId: batchId,
      summary: `Staged ${params.importType} batch ${params.fileName} (${params.periodStart} to ${params.periodEnd}; ${validRows} valid, ${correctionRows} corrections, ${errorRows} errors, ${duplicateRows} duplicates)`,
    });

    return { batch: batchDoc, rows: stagedRows };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `import_batches/${batchId}`);
  }
}

export async function approveImportBatch(batchId: string): Promise<void> {
  const user = auth.currentUser;
  if (!user) throw new Error('Authentication required.');
  const now = new Date().toISOString();
  try {
    await updateDoc(doc(db, 'import_batches', batchId), {
      status: 'APPROVED',
      approvedByEmail: (user.email || 'admin').slice(0, 180),
      updatedAt: now,
    });
    await recordAuditLog({
      action: 'IMPORT_BATCH_APPROVED',
      targetType: 'import_batch',
      targetId: batchId,
      summary: `Approved import batch ${batchId} for publishing`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `import_batches/${batchId}`);
  }
}

export async function rejectImportBatch(batchId: string, reason: string): Promise<void> {
  const now = new Date().toISOString();
  try {
    await updateDoc(doc(db, 'import_batches', batchId), {
      status: 'REJECTED',
      rejectionReason: reason.trim().slice(0, 300) || 'Rejected by Super Admin during review.',
      updatedAt: now,
    });
    await recordAuditLog({
      action: 'IMPORT_BATCH_REJECTED',
      targetType: 'import_batch',
      targetId: batchId,
      summary: `Rejected import batch ${batchId}: ${reason.trim().slice(0, 200)}`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `import_batches/${batchId}`);
  }
}

export async function publishApprovedBatch(params: {
  batch: ImportBatch;
  rows: ImportBatchRow[];
  employeesById: Record<string, Employee>;
}): Promise<{ publishedCount: number; correctedCount: number }> {
  const user = auth.currentUser;
  if (!user) throw new Error('Authentication required.');

  const actionableRows = params.rows.filter(
    (r) =>
      (r.resolution === 'PUBLISH_NEW' && r.validationStatus === 'VALID') ||
      (r.resolution === 'CORRECTION' && r.validationStatus === 'EXISTS_PUBLISHED'),
  );

  if (actionableRows.length === 0) {
    throw new Error('No publishable or correction rows exist in this batch.');
  }

  const now = new Date().toISOString();
  const labels: ComponentLabels = params.batch.componentLabels || {
    component1: 'Incentive New Quantity Wise',
    component2: 'Old Incentive',
    component3: 'Incentive - 0.50%',
  };

  // Fetch current published records to enforce server-fresh overlap protection & double-counting-safe summaries
  const existingPublishedList = await listAllPublishedIncentives();
  const publishedMap = new Map<string, PublishedIncentive>();
  for (const rec of existingPublishedList) {
    publishedMap.set(rec.recordId, rec);
  }

  const batchImportType: ImportType = params.batch.importType || 'DAILY';
  const batchPeriodStart = params.batch.periodStart || params.batch.businessDate;
  const batchPeriodEnd = params.batch.periodEnd || params.batch.businessDate;

  // Hard overlap safety check right before publishing
  for (const row of actionableRows) {
    const rowImportType: ImportType = row.importType || batchImportType;
    const rowStart = row.periodStart || batchPeriodStart;
    const rowEnd = row.periodEnd || batchPeriodEnd;
    const recordId = getIncentiveRecordKey(rowImportType, rowStart, rowEnd, row.employeeId);
    const conflicts = detectPeriodOverlapsForEmployee({
      employeeId: row.employeeId,
      incomingImportType: rowImportType,
      incomingStart: rowStart,
      incomingEnd: rowEnd,
      incomingRecordKey: recordId,
      publishedIncentives: existingPublishedList,
    });
    if (conflicts.length > 0) {
      throw new Error(
        `Publish blocked: Salesman No ${row.employeeId} (${rowImportType} ${rowStart} to ${rowEnd}) overlaps existing published ${conflicts[0].conflictingImportType} record (${conflicts[0].conflictingPeriodStart} to ${conflicts[0].conflictingPeriodEnd}).`,
      );
    }
  }

  let publishedCount = 0;
  let correctedCount = 0;
  const affectedSummaryKeys = new Map<string, { employee: Employee; monthKey: string }>();
  const pendingSets: Array<{ ref: ReturnType<typeof doc>; data: unknown }> = [];

  try {
    for (const row of actionableRows) {
      const emp = params.employeesById[sanitizeId(row.employeeId)];
      if (!emp) continue;

      const rowImportType: ImportType = row.importType || batchImportType;
      const rowStart = row.periodStart || batchPeriodStart;
      const rowEnd = row.periodEnd || batchPeriodEnd;
      const recordId = getIncentiveRecordKey(rowImportType, rowStart, rowEnd, row.employeeId);
      const businessDate = rowImportType === 'DAILY' ? rowStart : rowEnd;
      const monthKey = rowStart.slice(0, 7);

      const existingSnap = await getDoc(doc(db, 'published_incentives', recordId));
      const existingRec = existingSnap.exists() ? (existingSnap.data() as PublishedIncentive) : null;

      if (existingRec && row.resolution !== 'CORRECTION') {
        // Strict safeguard: never silently overwrite previously published records
        continue;
      }

      if (existingRec && row.resolution === 'CORRECTION') {
        const { updatedRecord, versionSnapshot } = applyPublishedCorrection({
          existingRecord: existingRec,
          newComponent1Paise: row.component1Paise,
          newComponent2Paise: row.component2Paise,
          newComponent3Paise: row.component3Paise,
          correctionReason: row.correctionReason || 'Approved batch correction',
          batchId: params.batch.batchId,
          actorEmail: user.email || 'admin',
          now,
          employeeName: emp.fullName,
          branchId: emp.branchId,
          branchName: emp.branchName,
          authUid: emp.authUid || '',
        });

        pendingSets.push({
          ref: doc(db, 'incentive_versions', versionSnapshot.versionId),
          data: versionSnapshot,
        });
        pendingSets.push({
          ref: doc(db, 'published_incentives', recordId),
          data: updatedRecord,
        });
        publishedMap.set(recordId, updatedRecord);
        correctedCount += 1;
      } else {
        const newRecord: PublishedIncentive = {
          recordId,
          importType: rowImportType,
          periodStart: rowStart,
          periodEnd: rowEnd,
          businessDate,
          monthKey,
          employeeId: emp.employeeId,
          authUid: emp.authUid || '',
          employeeName: emp.fullName,
          branchId: emp.branchId,
          branchName: emp.branchName,
          component1Label: labels.component1,
          component2Label: labels.component2,
          component3Label: labels.component3,
          component1Paise: row.component1Paise,
          component2Paise: row.component2Paise,
          component3Paise: row.component3Paise,
          totalPaise: row.totalPaise,
          status: 'PUBLISHED',
          version: 1,
          batchId: params.batch.batchId,
          publishedAt: now,
          publishedByEmail: (user.email || 'admin').slice(0, 180),
        };
        pendingSets.push({ ref: doc(db, 'published_incentives', recordId), data: newRecord });
        publishedMap.set(recordId, newRecord);
        publishedCount += 1;
      }

      // Only DAILY and MONTHLY records affect monthly_summaries (CUSTOM_PERIOD stays logically separate!)
      if (rowImportType === 'DAILY' || rowImportType === 'MONTHLY') {
        affectedSummaryKeys.set(`${emp.employeeId}_${monthKey}`, { employee: emp, monthKey });
      }

      const periodText =
        rowImportType === 'DAILY'
          ? formatShortDate(rowStart)
          : `${formatShortDate(rowStart)} to ${formatShortDate(rowEnd)}`;
      const typeLabel = formatImportTypeLabel(rowImportType);

      const notifId = generateRecordId('NTF');
      const notif: EmployeeNotification = {
        notificationId: notifId,
        employeeId: emp.employeeId,
        authUid: emp.authUid || '',
        title: existingRec ? `${typeLabel} Revised` : `${typeLabel} Published`,
        message: existingRec
          ? `Your ${typeLabel.toLowerCase()} for ${periodText} has been revised and published.`
          : `Your ${typeLabel.toLowerCase()} for ${periodText} is now available in your statement.`,
        importType: rowImportType,
        periodStart: rowStart,
        periodEnd: rowEnd,
        businessDate,
        batchId: params.batch.batchId,
        read: false,
        createdAt: now,
      };
      pendingSets.push({ ref: doc(db, 'notifications', notifId), data: notif });
    }

    // Recompute affected monthly_summaries cleanly from full post-publish state (ZERO double counting)
    const allPostPublishRecords = Array.from(publishedMap.values());
    for (const [summaryId, info] of affectedSummaryKeys.entries()) {
      const summaryDoc = buildMonthlySummaryDocument({
        records: allPostPublishRecords,
        employee: info.employee,
        monthKey: info.monthKey,
        now,
      });
      pendingSets.push({ ref: doc(db, 'monthly_summaries', summaryId), data: summaryDoc });
    }

    for (let i = 0; i < pendingSets.length; i += 400) {
      const wb = writeBatch(db);
      for (const op of pendingSets.slice(i, i + 400)) {
        wb.set(op.ref, op.data);
      }
      await wb.commit();
    }

    await updateDoc(doc(db, 'import_batches', params.batch.batchId), {
      status: 'PUBLISHED',
      publishedByEmail: (user.email || 'admin').slice(0, 180),
      updatedAt: now,
    });

    await recordAuditLog({
      action: 'IMPORT_BATCH_PUBLISHED',
      targetType: 'import_batch',
      targetId: params.batch.batchId,
      summary: `Published ${batchImportType} batch ${params.batch.batchId} (${batchPeriodStart} to ${batchPeriodEnd}): ${publishedCount} new records, ${correctedCount} versioned corrections.`,
    });

    return { publishedCount, correctedCount };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `import_batches/${params.batch.batchId}`);
  }
}

// --- EMPLOYEE-SCOPED READS (ANTI-IDOR: Strictly keyed by auth.currentUser.uid) ---
export async function fetchOwnEmployeeProfile(): Promise<Employee | null> {
  const user = auth.currentUser;
  if (!user) return null;
  try {
    const byUidSnap = await getDocs(
      query(collection(db, 'employees'), where('authUid', '==', user.uid)),
    );
    if (!byUidSnap.empty) {
      return byUidSnap.docs[0].data() as Employee;
    }
    if (user.email && user.emailVerified) {
      const byGoogleSnap = await getDocs(
        query(collection(db, 'employees'), where('linkedGoogleEmail', '==', user.email.toLowerCase())),
      );
      if (!byGoogleSnap.empty) {
        return byGoogleSnap.docs[0].data() as Employee;
      }
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'employees');
  }
}

export async function fetchOwnPublishedIncentives(): Promise<PublishedIncentive[]> {
  const user = auth.currentUser;
  if (!user) return [];
  try {
    const snap = await getDocs(
      query(
        collection(db, 'published_incentives'),
        where('authUid', '==', user.uid),
        where('status', '==', 'PUBLISHED'),
      ),
    );
    return snap.docs
      .map((d) => d.data() as PublishedIncentive)
      .sort((a, b) => (b.periodStart || b.businessDate).localeCompare(a.periodStart || a.businessDate));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'published_incentives');
  }
}

export async function fetchOwnMonthlySummaries(): Promise<MonthlySummary[]> {
  const user = auth.currentUser;
  if (!user) return [];
  try {
    const snap = await getDocs(
      query(collection(db, 'monthly_summaries'), where('authUid', '==', user.uid)),
    );
    return snap.docs
      .map((d) => d.data() as MonthlySummary)
      .sort((a, b) => b.monthKey.localeCompare(a.monthKey));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'monthly_summaries');
  }
}

export async function fetchOwnNotifications(): Promise<EmployeeNotification[]> {
  const user = auth.currentUser;
  if (!user) return [];
  try {
    const snap = await getDocs(
      query(collection(db, 'notifications'), where('authUid', '==', user.uid)),
    );
    return snap.docs
      .map((d) => d.data() as EmployeeNotification)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'notifications');
  }
}

export async function markNotificationRead(notificationId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), {
      read: true,
      readAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `notifications/${notificationId}`);
  }
}
