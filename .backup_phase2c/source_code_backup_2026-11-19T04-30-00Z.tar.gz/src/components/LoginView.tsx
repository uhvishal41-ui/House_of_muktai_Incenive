import React, { useState } from 'react';
import { ArrowRight, Eye, EyeOff, KeyRound, Lock, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function LoginView() {
  const {
    portalMode,
    setPortalMode,
    signInAdminWithGoogle,
    signInEmployeeWithLoginId,
    signInEmployeeWithGoogle,
  } = useAuth();

  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAdminGoogleLogin = async () => {
    setError(null);
    setBusy(true);
    try {
      await signInAdminWithGoogle();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to complete Super Admin sign-in.';
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  const handleEmployeeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginId.trim() || !password) {
      setError('Enter both your assigned Login ID and password.');
      return;
    }
    setError(null);
    setBusy(true);
    try {
      await signInEmployeeWithLoginId(loginId, password);
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/operation-not-allowed') {
        setError(
          'Email/Password sign-in is not yet enabled in Firebase Console. Enable Authentication -> Sign-in method -> Email/Password, or use Google Sign-In if linked by Admin.',
        );
      } else if (
        code === 'auth/invalid-credential' ||
        code === 'auth/user-not-found' ||
        code === 'auth/wrong-password'
      ) {
        setError('Invalid Login ID or password. Contact your House of Muktai administrator.');
      } else {
        setError(err instanceof Error ? err.message : 'Sign-in failed. Please try again.');
      }
    } finally {
      setBusy(false);
    }
  };

  const handleEmployeeGoogleLogin = async () => {
    setError(null);
    setBusy(true);
    try {
      await signInEmployeeWithGoogle();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col">
      <header className="w-full border-b border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            House of Muktai
          </span>
          <div className="text-xs text-slate-500 hidden sm:flex items-center gap-2 whitespace-nowrap">
            <span>Employee Incentive Management</span>
            <span aria-hidden="true">·</span>
            <span>12 Branches</span>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 bg-white border border-slate-200 rounded-xl overflow-hidden">
          {/* Left editorial panel */}
          <div className="lg:col-span-5 bg-slate-900 text-white p-8 lg:p-10 flex flex-col justify-between">
            <div>
              <p className="text-xs font-medium text-rose-200 tracking-wide mb-3">
                Standalone Incentive Platform
              </p>
              <h1
                className="text-2xl lg:text-3xl font-semibold tracking-tight leading-snug text-white mb-4"
                style={{ textWrap: 'balance' }}
              >
                Transparent Daily &amp; Monthly Incentive Statements
              </h1>
              <p className="text-sm text-slate-300 leading-relaxed">
                Dedicated workspace for House of Muktai across all 12 retail branches. Daily Excel
                imports are validated, approved, and version-controlled before publishing to
                individual employee accounts.
              </p>
            </div>

            <div className="mt-10 pt-6 border-t border-slate-800 space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" />
                <span>Strict per-employee isolation — no peer data or sales amounts exposed.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" />
                <span>Draft, rejected, and pending batches remain completely hidden from staff.</span>
              </div>
            </div>
          </div>

          {/* Right auth form panel */}
          <div className="lg:col-span-7 p-8 lg:p-10 flex flex-col justify-center">
            <div className="mb-8">
              <div className="inline-flex p-1 bg-slate-100 rounded-lg mb-6" role="tablist">
                <button
                  type="button"
                  role="tab"
                  aria-selected={portalMode === 'admin'}
                  onClick={() => {
                    setPortalMode('admin');
                    setError(null);
                  }}
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    portalMode === 'admin'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Super Admin Panel
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={portalMode === 'staff'}
                  onClick={() => {
                    setPortalMode('staff');
                    setError(null);
                  }}
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    portalMode === 'staff'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Employee Portal
                </button>
              </div>

              {portalMode === 'admin' ? (
                <>
                  <h2 className="text-xl font-semibold text-slate-900 mb-1.5">
                    Super Admin Sign In
                  </h2>
                  <p className="text-sm text-slate-500">
                    Access Branch Master, Employee Master, ExcelJS daily imports, approvals, and
                    audit logs.
                  </p>
                </>
              ) : (
                <>
                  <h2 className="text-xl font-semibold text-slate-900 mb-1.5">
                    Employee Incentive Sign In
                  </h2>
                  <p className="text-sm text-slate-500">
                    Sign in using the Login ID and password issued by House of Muktai administration.
                  </p>
                </>
              )}
            </div>

            {error && (
              <div
                role="alert"
                className="mb-6 p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800 leading-relaxed"
              >
                {error}
              </div>
            )}

            {portalMode === 'admin' ? (
              <div className="space-y-4">
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleAdminGoogleLogin}
                  className="w-full h-11 px-4 rounded-lg bg-rose-900 hover:bg-rose-950 text-white text-sm font-medium inline-flex items-center justify-center gap-2.5 transition-colors disabled:opacity-60 cursor-pointer"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>{busy ? 'Authenticating...' : 'Continue with Authorized Google Account'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Admin console access is restricted to verified Super Admin accounts registered for
                  House of Muktai (`admin.homfash.com`).
                </p>
              </div>
            ) : (
              <form onSubmit={handleEmployeeLogin} className="space-y-4">
                <div>
                  <label htmlFor="loginId" className="block text-sm font-medium text-slate-700 mb-1.5">
                    Employee Login ID
                  </label>
                  <input
                    id="loginId"
                    type="text"
                    autoComplete="username"
                    placeholder="e.g. HOM001"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value.toUpperCase())}
                    className="w-full h-11 px-3.5 rounded-lg border border-slate-300 bg-white text-sm text-slate-900 font-mono placeholder:font-sans placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-900/20 focus:border-rose-900"
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full h-11 pl-3.5 pr-11 rounded-lg border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-900/20 focus:border-rose-900"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-1 top-1 h-9 w-9 inline-flex items-center justify-center text-slate-500 hover:text-slate-900 rounded-md cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full h-11 px-4 rounded-lg bg-rose-900 hover:bg-rose-950 text-white text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors disabled:opacity-60 cursor-pointer"
                >
                  <span>{busy ? 'Signing in...' : 'Sign In to My Incentives'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="relative py-2">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200" />
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-white px-3 text-slate-400">or if linked by Admin</span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={busy}
                  onClick={handleEmployeeGoogleLogin}
                  className="w-full h-11 px-4 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-sm font-medium transition-colors disabled:opacity-60 cursor-pointer"
                >
                  Sign In with Linked Google Account
                </button>
              </form>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
