import React, { useMemo } from 'react';
import { ArrowUpRight, FileSpreadsheet, Users } from 'lucide-react';
import {
  formatINRFromPaise,
  formatMonthLabel,
  formatShortDate,
  getCurrentMonthKeyIST,
} from '../../lib/format';
import type {
  Branch,
  Employee,
  ImportBatch,
  MonthlySummary,
  PublishedIncentive,
} from '../../types/incentive';

interface Props {
  branches: Branch[];
  employees: Employee[];
  batches: ImportBatch[];
  incentives: PublishedIncentive[];
  monthlySummaries: MonthlySummary[];
  onNavigate: (tab: 'branches' | 'employees' | 'import' | 'history') => void;
}

export function AdminOverview({
  branches,
  employees,
  batches,
  incentives,
  monthlySummaries,
  onNavigate,
}: Props) {
  const currentMonth = getCurrentMonthKeyIST();

  const metrics = useMemo(() => {
    const monthSummaries = monthlySummaries.filter((s) => s.monthKey === currentMonth);
    const totalMonthPaise = monthSummaries.reduce((acc, s) => acc + s.grandTotalPaise, 0);
    const activeBranches = branches.filter((b) => b.active).length;
    const activeEmployees = employees.filter((e) => e.status === 'ACTIVE').length;
    const pendingBatches = batches.filter(
      (b) => b.status === 'VALIDATED' || b.status === 'APPROVED',
    ).length;

    const branchTotalsMap: Record<string, { name: string; totalPaise: number; count: number }> = {};
    for (const b of branches) {
      branchTotalsMap[b.branchId] = { name: b.branchName, totalPaise: 0, count: 0 };
    }
    for (const s of monthSummaries) {
      if (!branchTotalsMap[s.branchId]) {
        branchTotalsMap[s.branchId] = { name: s.branchName, totalPaise: 0, count: 0 };
      }
      branchTotalsMap[s.branchId].totalPaise += s.grandTotalPaise;
      branchTotalsMap[s.branchId].count += 1;
    }

    const branchBreakdown = Object.entries(branchTotalsMap)
      .map(([id, data]) => ({ branchId: id, ...data }))
      .sort((a, b) => b.totalPaise - a.totalPaise);

    const maxBranchPaise = Math.max(1, ...branchBreakdown.map((b) => b.totalPaise));

    return {
      totalMonthPaise,
      activeBranches,
      activeEmployees,
      pendingBatches,
      branchBreakdown,
      maxBranchPaise,
    };
  }, [branches, employees, batches, monthlySummaries, currentMonth]);

  const recentBatches = batches.slice(0, 6);
  const latestPublishedDate = incentives[0]?.businessDate || null;

  return (
    <div className="space-y-8">
      {/* Top 4-column KPI strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 mb-2">
            Published Incentives · {formatMonthLabel(currentMonth)}
          </p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {formatINRFromPaise(metrics.totalMonthPaise)}
          </p>
          <p className="text-xs text-slate-500 mt-2">
            {latestPublishedDate
              ? `Latest date: ${formatShortDate(latestPublishedDate)}`
              : 'No published batches yet'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 mb-2">Active Retail Branches</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {metrics.activeBranches}
            <span className="text-sm font-normal text-slate-400"> / {branches.length || 12}</span>
          </p>
          <button
            type="button"
            onClick={() => onNavigate('branches')}
            className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-rose-900 hover:underline cursor-pointer"
          >
            Manage Branch Master
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 mb-2">Active Employees</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {metrics.activeEmployees}
          </p>
          <button
            type="button"
            onClick={() => onNavigate('employees')}
            className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-rose-900 hover:underline cursor-pointer"
          >
            Manage Employee Accounts
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 mb-2">Pending Approval / Publish</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {metrics.pendingBatches}
          </p>
          <button
            type="button"
            onClick={() => onNavigate(metrics.pendingBatches > 0 ? 'history' : 'import')}
            className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-rose-900 hover:underline cursor-pointer"
          >
            {metrics.pendingBatches > 0 ? 'Review Pending Batches' : 'Upload Daily Excel'}
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main two-column operational section */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Branch-wise incentive distribution */}
        <section className="xl:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Branch-Wise Published Incentives
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {formatMonthLabel(currentMonth)} · Double-counting-safe monthly aggregation
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('import')}
              className="px-3.5 py-2 text-xs font-medium text-white bg-rose-900 hover:bg-rose-950 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Import ERP Excel
            </button>
          </div>

          {metrics.branchBreakdown.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
              <p className="text-sm text-slate-600 mb-3">
                No branches configured yet. Initialize the 12 House of Muktai branches to begin.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('branches')}
                className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                Open Branch Master
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {metrics.branchBreakdown.map((item) => {
                const widthPct =
                  item.totalPaise > 0
                    ? Math.max(4, Math.round((item.totalPaise / metrics.maxBranchPaise) * 100))
                    : 0;
                return (
                  <div key={item.branchId} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm gap-4">
                      <span className="text-slate-700 font-medium truncate">
                        {item.name}
                      </span>
                      <span className="font-mono tabular-nums text-slate-900 font-medium shrink-0">
                        {formatINRFromPaise(item.totalPaise)}
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-sm overflow-hidden">
                      <div
                        className="h-full bg-rose-900 rounded-sm transition-all duration-300"
                        style={{ width: `${widthPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Recent Import Batches */}
        <section className="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Recent Import Batches</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Daily, Monthly &amp; Custom Period audit queue
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer whitespace-nowrap"
            >
              View All
            </button>
          </div>

          {recentBatches.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
              <Users className="w-6 h-6 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-600 mb-1">No Excel imports uploaded yet</p>
              <p className="text-xs text-slate-500">
                Download a sample .xlsx template or upload an ERP sheet to test validation and
                publishing.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentBatches.map((batch) => {
                const statusColor =
                  batch.status === 'PUBLISHED'
                    ? 'text-emerald-700'
                    : batch.status === 'REJECTED'
                      ? 'text-red-700'
                      : 'text-amber-700';
                const batchType = batch.importType || 'DAILY';
                const periodLabel =
                  batchType === 'DAILY'
                    ? batch.periodStart || batch.businessDate
                    : `${batch.periodStart || batch.businessDate} → ${batch.periodEnd || batch.businessDate}`;
                return (
                  <div key={batch.batchId} className="py-3.5 first:pt-0 last:pb-0">
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm font-medium text-slate-900 truncate">{batch.fileName}</p>
                      <span className={`text-xs font-semibold shrink-0 ${statusColor}`}>
                        {batch.status}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-mono font-semibold text-rose-900">{batchType}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{periodLabel}</span>
                        <span aria-hidden="true">·</span>
                        <span>{batch.totalRows} rows</span>
                      </div>
                      <span className="font-mono tabular-nums text-slate-700 shrink-0">
                        {formatINRFromPaise(batch.totalIncentivePaise)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
