import React, { useState } from 'react';
import { Building2, Edit3, Plus, Search } from 'lucide-react';
import { initializeDefault12Branches, saveBranch } from '../../services/incentiveService';
import type { Branch } from '../../types/incentive';

interface Props {
  branches: Branch[];
  onRefresh: () => Promise<void>;
}

export function BranchMaster({ branches, onRefresh }: Props) {
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Branch | null>(null);
  const [branchCode, setBranchCode] = useState('');
  const [branchName, setBranchName] = useState('');
  const [city, setCity] = useState('');
  const [managerName, setManagerName] = useState('');
  const [active, setActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const filtered = branches.filter(
    (b) =>
      b.branchCode.toLowerCase().includes(search.toLowerCase()) ||
      b.branchName.toLowerCase().includes(search.toLowerCase()) ||
      b.city.toLowerCase().includes(search.toLowerCase()),
  );

  const openCreate = () => {
    setEditing(null);
    setBranchCode(`HOM-${String(branches.length + 1).padStart(2, '0')}`);
    setBranchName('');
    setCity('');
    setManagerName('');
    setActive(true);
    setShowForm(true);
  };

  const openEdit = (branch: Branch) => {
    setEditing(branch);
    setBranchCode(branch.branchCode);
    setBranchName(branch.branchName);
    setCity(branch.city);
    setManagerName(branch.managerName || '');
    setActive(branch.active);
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchCode.trim() || !branchName.trim() || !city.trim()) return;
    setSaving(true);
    setMessage(null);
    try {
      await saveBranch({
        branchId: editing?.branchId,
        branchCode,
        branchName,
        city,
        managerName,
        active,
        existingCreatedAt: editing?.createdAt,
      });
      setShowForm(false);
      setMessage(editing ? 'Branch updated successfully.' : 'Branch created successfully.');
      await onRefresh();
    } finally {
      setSaving(false);
    }
  };

  const handleInit12 = async () => {
    setSeeding(true);
    setMessage(null);
    try {
      const count = await initializeDefault12Branches();
      setMessage(`Initialized ${count} House of Muktai branches. You can rename any branch or city anytime.`);
      await onRefresh();
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search branch code, name, or city..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-10 pl-9 pr-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-900/20 focus:border-rose-900"
          />
        </div>
        <div className="flex items-center gap-3">
          {branches.length === 0 && (
            <button
              type="button"
              disabled={seeding}
              onClick={handleInit12}
              className="h-10 px-4 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium inline-flex items-center gap-2 whitespace-nowrap cursor-pointer disabled:opacity-60"
            >
              <Building2 className="w-4 h-4" />
              {seeding ? 'Initializing...' : 'Initialize 12 Branches'}
            </button>
          )}
          <button
            type="button"
            onClick={openCreate}
            className="h-10 px-4 rounded-lg bg-rose-900 hover:bg-rose-950 text-white text-sm font-medium inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Branch
          </button>
        </div>
      </div>

      {message && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
          {message}
        </div>
      )}

      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">
              {editing ? `Edit Branch · ${editing.branchCode}` : 'Create Branch Master Record'}
            </h3>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="text-xs font-medium text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Branch Code</label>
              <input
                type="text"
                required
                disabled={Boolean(editing)}
                value={branchCode}
                onChange={(e) => setBranchCode(e.target.value.toUpperCase())}
                placeholder="HOM-01"
                className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm font-mono disabled:bg-slate-50"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Branch Name</label>
              <input
                type="text"
                required
                value={branchName}
                onChange={(e) => setBranchName(e.target.value)}
                placeholder="House of Muktai — Flagship"
                className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Mumbai"
                className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Branch Manager (Optional)
              </label>
              <input
                type="text"
                value={managerName}
                onChange={(e) => setManagerName(e.target.value)}
                placeholder="Manager name"
                className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={active}
                onChange={(e) => setActive(e.target.checked)}
                className="rounded border-slate-300 text-rose-900 focus:ring-rose-900"
              />
              Branch is active for daily Excel imports
            </label>
            <button
              type="submit"
              disabled={saving}
              className="h-10 px-5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium disabled:opacity-60 cursor-pointer"
            >
              {saving ? 'Saving...' : editing ? 'Save Changes' : 'Save Branch'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-medium text-slate-800 mb-1">No branches found</p>
            <p className="text-xs text-slate-500">
              Use &ldquo;Initialize 12 Branches&rdquo; or add branches individually to validate daily
              Excel uploads.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Branch Code</th>
                  <th className="py-3 px-4">Branch Name</th>
                  <th className="py-3 px-4">City</th>
                  <th className="py-3 px-4">Manager</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((branch) => (
                  <tr key={branch.branchId} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">
                      {branch.branchCode}
                    </td>
                    <td className="py-3 px-4 text-slate-900 font-medium">{branch.branchName}</td>
                    <td className="py-3 px-4 text-slate-600">{branch.city}</td>
                    <td className="py-3 px-4 text-slate-600">{branch.managerName || '—'}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-xs font-semibold ${
                          branch.active ? 'text-emerald-700' : 'text-slate-500'
                        }`}
                      >
                        {branch.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => openEdit(branch)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-rose-900 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Edit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
