import React, { useCallback, useEffect, useState } from 'react';
import {
  Building2,
  FileSpreadsheet,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  RefreshCw,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  listAllMonthlySummaries,
  listAllPublishedIncentives,
  listAuditLogs,
  listBranches,
  listEmployees,
  listImportBatches,
  listIncentiveVersions,
} from '../../services/incentiveService';
import type {
  AuditLog,
  Branch,
  Employee,
  ImportBatch,
  IncentiveVersion,
  MonthlySummary,
  PublishedIncentive,
} from '../../types/incentive';
import { AdminOverview } from './AdminOverview';
import { BranchMaster } from './BranchMaster';
import { EmployeeMaster } from './EmployeeMaster';
import { ExcelImportWorkflow } from './ExcelImportWorkflow';
import { HistoryAndReports } from './HistoryAndReports';

type AdminTab = 'overview' | 'branches' | 'employees' | 'import' | 'history';

const NAV_ITEMS: Array<{ id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'branches', label: 'Branch Master', icon: Building2 },
  { id: 'employees', label: 'Employee Master', icon: Users },
  { id: 'import', label: 'Daily Excel Import', icon: FileSpreadsheet },
  { id: 'history', label: 'Reports & Audit', icon: History },
];

export function AdminShell() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [branches, setBranches] = useState<Branch[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [batches, setBatches] = useState<ImportBatch[]>([]);
  const [incentives, setIncentives] = useState<PublishedIncentive[]>([]);
  const [monthlySummaries, setMonthlySummaries] = useState<MonthlySummary[]>([]);
  const [versions, setVersions] = useState<IncentiveVersion[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  const refreshAll = useCallback(async () => {
    setLoadingData(true);
    try {
      const [b, e, ib, pi, ms, iv, al] = await Promise.all([
        listBranches(),
        listEmployees(),
        listImportBatches(),
        listAllPublishedIncentives(),
        listAllMonthlySummaries(),
        listIncentiveVersions(),
        listAuditLogs(),
      ]);
      setBranches(b);
      setEmployees(e);
      setBatches(ib);
      setIncentives(pi);
      setMonthlySummaries(ms);
      setVersions(iv);
      setAuditLogs(al);
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  const currentNavLabel = NAV_ITEMS.find((n) => n.id === activeTab)?.label || 'Overview';

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex">
      {/* Desktop Left Sidebar (256px) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white border-r border-slate-200 z-20">
        <div className="h-16 px-6 flex items-center border-b border-slate-200">
          <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
            House of Muktai
          </span>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full h-10 px-3 rounded-lg text-sm font-medium inline-flex items-center gap-3 transition-colors whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-rose-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200">
          <div className="mb-3 px-2">
            <p className="text-xs font-semibold text-slate-900 truncate">Super Admin</p>
            <p className="text-xs text-slate-500 truncate">{user?.email}</p>
          </div>
          <button
            type="button"
            onClick={logout}
            className="w-full h-9 px-3 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-medium text-slate-700 inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-64 max-w-xs bg-white h-full flex flex-col border-r border-slate-200 z-50">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200">
              <span className="text-base font-bold text-slate-900">House of Muktai</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-slate-500 hover:text-slate-900"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full h-11 px-3 rounded-lg text-sm font-medium inline-flex items-center gap-3 ${
                      active ? 'bg-rose-900 text-white' : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-200">
              <button
                type="button"
                onClick={logout}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 inline-flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Viewport */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-10 h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-400 hidden sm:inline whitespace-nowrap">Admin Panel</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <h1 className="font-semibold text-slate-900 truncate">{currentNavLabel}</h1>
            </div>
          </div>

          <button
            type="button"
            onClick={refreshAll}
            disabled={loadingData}
            className="h-9 px-3 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingData ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </header>

        <main className="flex-1 p-6 max-w-7xl w-full mx-auto">
          {loadingData && branches.length === 0 && batches.length === 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((n) => (
                  <div
                    key={n}
                    className="h-28 bg-white border border-slate-200 rounded-xl animate-pulse"
                  />
                ))}
              </div>
              <div className="h-80 bg-white border border-slate-200 rounded-xl animate-pulse" />
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <AdminOverview
                  branches={branches}
                  employees={employees}
                  batches={batches}
                  incentives={incentives}
                  monthlySummaries={monthlySummaries}
                  onNavigate={(tab) => setActiveTab(tab)}
                />
              )}
              {activeTab === 'branches' && (
                <BranchMaster branches={branches} onRefresh={refreshAll} />
              )}
              {activeTab === 'employees' && (
                <EmployeeMaster
                  branches={branches}
                  employees={employees}
                  onRefresh={refreshAll}
                />
              )}
              {activeTab === 'import' && (
                <ExcelImportWorkflow
                  branches={branches}
                  employees={employees}
                  publishedIncentives={incentives}
                  onRefresh={refreshAll}
                />
              )}
              {activeTab === 'history' && (
                <HistoryAndReports
                  branches={branches}
                  employees={employees}
                  batches={batches}
                  incentives={incentives}
                  monthlySummaries={monthlySummaries}
                  versions={versions}
                  auditLogs={auditLogs}
                  onRefresh={refreshAll}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
