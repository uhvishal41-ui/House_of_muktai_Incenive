import React, { useMemo, useState } from 'react';
import { CheckCircle2, Download, History, Shield, XCircle } from 'lucide-react';
import {
  formatINRFromPaise,
  formatMonthLabel,
  formatRupeesPlain,
  formatShortDate,
  getCurrentMonthKeyIST,
  getTodayIST,
} from '../../lib/format';
import { normalizeRecordPeriod } from '../../lib/incentiveEngine';
import {
  approveImportBatch,
  listBatchRows,
  publishApprovedBatch,
  recordAuditLog,
  rejectImportBatch,
} from '../../services/incentiveService';
import type {
  AuditLog,
  Branch,
  Employee,
  ImportBatch,
  IncentiveVersion,
  MonthlySummary,
  PublishedIncentive,
} from '../../types/incentive';

interface Props {
  branches: Branch[];
  employees: Employee[];
  batches: ImportBatch[];
  incentives: PublishedIncentive[];
  monthlySummaries: MonthlySummary[];
  versions: IncentiveVersion[];
  auditLogs: AuditLog[];
  onRefresh: () => Promise<void>;
}

type SubTab = 'batches' | 'corrections' | 'reports' | 'audit';

export function HistoryAndReports({
  branches,
  employees,
  batches,
  incentives,
  monthlySummaries,
  versions,
  auditLogs,
  onRefresh,
}: Props) {
  const [subTab, setSubTab] = useState<SubTab>('batches');
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonthKeyIST());
  const [selectedBranch, setSelectedBranch] = useState('ALL');
  const [busyBatchId, setBusyBatchId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const employeesById = useMemo(() => {
    const map: Record<string, Employee> = {};
    for (const e of employees) map[e.employeeId.toUpperCase()] = e;
    return map;
  }, [employees]);

  const availableMonths = useMemo(() => {
    const set = new Set<string>([getCurrentMonthKeyIST()]);
    for (const s of monthlySummaries) set.add(s.monthKey);
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [monthlySummaries]);

  const filteredSummaries = useMemo(() => {
    return monthlySummaries
      .filter((s) => s.monthKey === selectedMonth)
      .filter((s) => selectedBranch === 'ALL' || s.branchId === selectedBranch)
      .sort((a, b) => b.grandTotalPaise - a.grandTotalPaise);
  }, [monthlySummaries, selectedMonth, selectedBranch]);

  const reportTotals = useMemo(() => {
    return filteredSummaries.reduce(
      (acc, s) => ({
        c1: acc.c1 + s.component1TotalPaise,
        c2: acc.c2 + s.component2TotalPaise,
        c3: acc.c3 + s.component3TotalPaise,
        total: acc.total + s.grandTotalPaise,
      }),
      { c1: 0, c2: 0, c3: 0, total: 0 },
    );
  }, [filteredSummaries]);

  const customPeriodRecords = useMemo(() => {
    return incentives
      .filter((r) => normalizeRecordPeriod(r).importType === 'CUSTOM_PERIOD')
      .filter((r) => selectedBranch === 'ALL' || r.branchId === selectedBranch)
      .sort((a, b) =>
        normalizeRecordPeriod(b).periodStart.localeCompare(normalizeRecordPeriod(a).periodStart),
      );
  }, [incentives, selectedBranch]);

  const handleBatchApprove = async (batch: ImportBatch) => {
    setBusyBatchId(batch.batchId);
    setMessage(null);
    try {
      await approveImportBatch(batch.batchId);
      setMessage(`Approved batch ${batch.batchId}.`);
      await onRefresh();
    } finally {
      setBusyBatchId(null);
    }
  };

  const handleBatchPublish = async (batch: ImportBatch) => {
    setBusyBatchId(batch.batchId);
    setMessage(null);
    try {
      const rows = await listBatchRows(batch.batchId);
      const res = await publishApprovedBatch({ batch, rows, employeesById });
      setMessage(
        `Published batch ${batch.batchId}: ${res.publishedCount} new records, ${res.correctedCount} versioned corrections.`,
      );
      await onRefresh();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to publish batch.');
    } finally {
      setBusyBatchId(null);
    }
  };

  const handleBatchReject = async (batch: ImportBatch) => {
    setBusyBatchId(batch.batchId);
    setMessage(null);
    try {
      await rejectImportBatch(batch.batchId, 'Rejected from Upload History queue by Super Admin.');
      setMessage(`Rejected batch ${batch.batchId}.`);
      await onRefresh();
    } finally {
      setBusyBatchId(null);
    }
  };

  const handleExportJsonBackup = async () => {
    const snapshot = {
      exportedAt: new Date().toISOString(),
      organization: 'House of Muktai',
      branches,
      employees,
      importBatches: batches,
      publishedIncentives: incentives,
      monthlySummaries,
      incentiveVersions: versions,
      auditLogs,
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `house-of-muktai-full-backup-${getTodayIST()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    await recordAuditLog({
      action: 'BACKUP_JSON_EXPORTED',
      targetType: 'system',
      targetId: getTodayIST(),
      summary: `Exported full JSON database backup (${incentives.length} published incentives, ${employees.length} employees)`,
    });
    await onRefresh();
  };

  const handleExportCsvLedger = async () => {
    const header = [
      'Month',
      'Employee ID',
      'Employee Name',
      'Branch',
      'Component 1 (INR)',
      'Component 2 (INR)',
      'Component 3 (INR)',
      'Monthly Total (INR)',
      'Published Days',
    ].join(',');

    const lines = filteredSummaries.map((s) =>
      [
        s.monthKey,
        s.employeeId,
        `"${s.employeeName.replace(/"/g, '""')}"`,
        `"${s.branchName.replace(/"/g, '""')}"`,
        formatRupeesPlain(s.component1TotalPaise),
        formatRupeesPlain(s.component2TotalPaise),
        formatRupeesPlain(s.component3TotalPaise),
        formatRupeesPlain(s.grandTotalPaise),
        s.publishedDaysCount,
      ].join(','),
    );

    const blob = new Blob([[header, ...lines].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `house-of-muktai-monthly-report-${selectedMonth}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    await recordAuditLog({
      action: 'REPORT_CSV_EXPORTED',
      targetType: 'monthly_report',
      targetId: selectedMonth,
      summary: `Exported monthly incentive CSV report for ${selectedMonth} (${filteredSummaries.length} employees)`,
    });
    await onRefresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="inline-flex p-1 bg-slate-200/70 rounded-lg text-sm overflow-x-auto">
          {(
            [
              ['batches', `Upload Batches (${batches.length})`],
              ['corrections', `Correction History (${versions.length})`],
              ['reports', 'Monthly Reports'],
              ['audit', `Audit Logs (${auditLogs.length})`],
            ] as Array<[SubTab, string]>
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setSubTab(key)}
              className={`px-3.5 py-2 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                subTab === key
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleExportJsonBackup}
          className="h-9 px-3.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap self-start lg:self-auto cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          Export Full JSON Backup
        </button>
      </div>

      {message && (
        <div className="p-3.5 rounded-lg bg-slate-900 text-white text-sm">{message}</div>
      )}

      {subTab === 'batches' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {batches.length === 0 ? (
            <div className="p-12 text-center text-sm text-slate-500">
              No Excel import batches recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Batch / File</th>
                    <th className="py-3 px-4">Type &amp; Period</th>
                    <th className="py-3 px-4 text-right">Rows (Valid / Corr / Err)</th>
                    <th className="py-3 px-4 text-right">Incentive Total</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {batches.map((b) => {
                    const bType = b.importType || 'DAILY';
                    const bStart = b.periodStart || b.businessDate;
                    const bEnd = b.periodEnd || b.businessDate;
                    return (
                    <tr key={b.batchId} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{b.fileName}</div>
                        <div className="text-xs text-slate-500 font-mono">
                          {b.batchId} · {b.uploadedByEmail}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-700">
                        <div className="font-semibold text-rose-900">{bType}</div>
                        <div>{bType === 'DAILY' ? bStart : `${bStart} → ${bEnd}`}</div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-xs text-slate-700">
                        {b.validRows} / {b.correctionRows} / {b.errorRows}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-slate-900">
                        {formatINRFromPaise(b.totalIncentivePaise)}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-xs font-semibold ${
                            b.status === 'PUBLISHED'
                              ? 'text-emerald-700'
                              : b.status === 'REJECTED'
                                ? 'text-red-700'
                                : 'text-amber-700'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          {b.status === 'VALIDATED' && (
                            <>
                              <button
                                type="button"
                                disabled={busyBatchId === b.batchId}
                                onClick={() => handleBatchApprove(b)}
                                className="text-xs font-medium text-slate-900 hover:text-rose-900 cursor-pointer"
                              >
                                Approve
                              </button>
                              <span className="text-slate-300">/</span>
                              <button
                                type="button"
                                disabled={busyBatchId === b.batchId}
                                onClick={() => handleBatchReject(b)}
                                className="text-xs font-medium text-red-700 hover:underline cursor-pointer"
                              >
                                Reject
                              </button>
                            </>
                          )}
                          {b.status === 'APPROVED' && (
                            <button
                              type="button"
                              disabled={busyBatchId === b.batchId}
                              onClick={() => handleBatchPublish(b)}
                              className="px-2.5 py-1 rounded bg-rose-900 text-white text-xs font-medium hover:bg-rose-950 cursor-pointer"
                            >
                              {busyBatchId === b.batchId ? 'Publishing...' : 'Publish'}
                            </button>
                          )}
                          {(b.status === 'PUBLISHED' || b.status === 'REJECTED') && (
                            <span className="text-xs text-slate-400">Closed</span>
                          )}
                        </div>
                      </td>
                    </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {subTab === 'corrections' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {versions.length === 0 ? (
            <div className="p-12 text-center">
              <History className="w-6 h-6 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-600">No published incentive corrections recorded yet.</p>
              <p className="text-xs text-slate-500 mt-1">
                Every approved revision preserves the prior version here before updating published totals.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Date &amp; Employee</th>
                    <th className="py-3 px-4">Version Change</th>
                    <th className="py-3 px-4 text-right">Previous Total</th>
                    <th className="py-3 px-4 text-right">Revised Total</th>
                    <th className="py-3 px-4">Correction Reason</th>
                    <th className="py-3 px-4">Corrected By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {versions.map((v) => (
                    <tr key={v.versionId} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono text-xs text-slate-900">
                        {v.businessDate} · {v.employeeId}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-700">
                        v{v.previousVersion} → v{v.newVersion}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500">
                        {formatINRFromPaise(v.previousTotalPaise)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {formatINRFromPaise(v.newTotalPaise)}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-700">{v.correctionReason}</td>
                      <td className="py-3 px-4 text-xs text-slate-500">{v.correctedByEmail}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {subTab === 'reports' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-800"
              >
                {availableMonths.map((m) => (
                  <option key={m} value={m}>
                    {formatMonthLabel(m)}
                  </option>
                ))}
              </select>
              <select
                value={selectedBranch}
                onChange={(e) => setSelectedBranch(e.target.value)}
                className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-800"
              >
                <option value="ALL">All 12 Branches</option>
                {branches.map((b) => (
                  <option key={b.branchId} value={b.branchId}>
                    {b.branchCode} — {b.branchName}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleExportCsvLedger}
              disabled={filteredSummaries.length === 0}
              className="h-9 px-3.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export Monthly CSV
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            {filteredSummaries.length === 0 ? (
              <div className="p-12 text-center text-sm text-slate-500">
                No published monthly summaries for {formatMonthLabel(selectedMonth)}.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                      <th className="py-3 px-4">Employee</th>
                      <th className="py-3 px-4">Branch</th>
                      <th className="py-3 px-4">Source</th>
                      <th className="py-3 px-4 text-right">Component 1</th>
                      <th className="py-3 px-4 text-right">Component 2</th>
                      <th className="py-3 px-4 text-right">Component 3</th>
                      <th className="py-3 px-4 text-right">Monthly Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredSummaries.map((s) => (
                      <tr key={s.summaryId} className="hover:bg-slate-50/60">
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-900">{s.employeeName}</div>
                          <div className="text-xs font-mono text-slate-500">{s.employeeId}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-700">{s.branchName}</td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          {s.sourceType === 'MONTHLY_RECORD'
                            ? 'Monthly Import'
                            : `Daily Sum (${s.publishedDaysCount}d)`}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINRFromPaise(s.component1TotalPaise)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINRFromPaise(s.component2TotalPaise)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINRFromPaise(s.component3TotalPaise)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                          {formatINRFromPaise(s.grandTotalPaise)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-slate-200 bg-slate-50 font-semibold text-slate-900">
                      <td className="py-3 px-4" colSpan={3}>
                        Grand Total ({filteredSummaries.length} Employees)
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatINRFromPaise(reportTotals.c1)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatINRFromPaise(reportTotals.c2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatINRFromPaise(reportTotals.c3)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-rose-900">
                        {formatINRFromPaise(reportTotals.total)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* Separate Custom Period Statements Table (Never Mixed Into Monthly Sums) */}
          {customPeriodRecords.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">
                  Custom Period Statements ({customPeriodRecords.length})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stored separately with exact start and end dates. Never added into Monthly Totals
                  to prevent double counting.
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                      <th className="py-3 px-4">Period Range</th>
                      <th className="py-3 px-4">Employee</th>
                      <th className="py-3 px-4">Branch</th>
                      <th className="py-3 px-4 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {customPeriodRecords.map((rec) => {
                      const norm = normalizeRecordPeriod(rec);
                      return (
                        <tr key={rec.recordId} className="hover:bg-slate-50/60">
                          <td className="py-3 px-4 font-mono tabular-nums text-slate-800 whitespace-nowrap">
                            {formatShortDate(norm.periodStart)} – {formatShortDate(norm.periodEnd)}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-medium text-slate-900">{rec.employeeName}</span>{' '}
                            <span className="font-mono text-slate-500">({rec.employeeId})</span>
                          </td>
                          <td className="py-3 px-4 text-slate-700">{rec.branchName}</td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                            {formatINRFromPaise(rec.totalPaise)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {subTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {auditLogs.length === 0 ? (
            <div className="p-12 text-center">
              <Shield className="w-6 h-6 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-600">No audit events recorded yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Timestamp (IST)</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">Actor</th>
                    <th className="py-3 px-4">Target</th>
                    <th className="py-3 px-4">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {auditLogs.map((log) => (
                    <tr key={log.logId} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-500 whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString('en-IN', {
                          timeZone: 'Asia/Kolkata',
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 whitespace-nowrap">
                        {log.action.includes('REJECT') ? (
                          <span className="inline-flex items-center gap-1 text-red-700">
                            <XCircle className="w-3.5 h-3.5" />
                            {log.action}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {log.action}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-700">{log.actorEmail}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {log.targetType} / {log.targetId}
                      </td>
                      <td className="py-3 px-4 text-slate-700">{log.summary}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
