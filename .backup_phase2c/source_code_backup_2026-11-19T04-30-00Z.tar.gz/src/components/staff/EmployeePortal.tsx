import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Bell,
  Calendar,
  Check,
  Home,
  KeyRound,
  LogOut,
  ShieldOff,
  TrendingDown,
  TrendingUp,
  User,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  formatINRFromPaise,
  formatMonthLabel,
  formatShortDate,
  getCurrentMonthKeyIST,
  getPreviousMonthKey,
} from '../../lib/format';
import {
  aggregateEmployeeMonth,
  formatImportTypeLabel,
  normalizeRecordPeriod,
  partitionEmployeeRecords,
} from '../../lib/incentiveEngine';
import {
  fetchOwnMonthlySummaries,
  fetchOwnNotifications,
  fetchOwnPublishedIncentives,
  markNotificationRead,
  updateOwnEmployeeProfile,
} from '../../services/incentiveService';
import type {
  EmployeeNotification,
  MonthlySummary,
  PublishedIncentive,
} from '../../types/incentive';

type StaffTab = 'home' | 'statements' | 'history' | 'profile';

export function EmployeePortal() {
  const {
    employeeProfile,
    employeeLoginGate,
    logout,
    changeOwnPassword,
    refreshEmployeeProfile,
  } = useAuth();
  const [activeTab, setActiveTab] = useState<StaffTab>('home');
  const [incentives, setIncentives] = useState<PublishedIncentive[]>([]);
  const [summaries, setSummaries] = useState<MonthlySummary[]>([]);
  const [notifications, setNotifications] = useState<EmployeeNotification[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonthKeyIST());
  const [loading, setLoading] = useState(true);

  // Profile form state
  const [phone, setPhone] = useState(employeeProfile?.phone || '');
  const [address, setAddress] = useState(employeeProfile?.address || '');
  const [emergencyContact, setEmergencyContact] = useState(employeeProfile?.emergencyContact || '');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileMessage, setProfileMessage] = useState<string | null>(null);

  // Change password state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdSaving, setPwdSaving] = useState(false);
  const [pwdMessage, setPwdMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const loadData = useCallback(async () => {
    if (!employeeLoginGate.allowed) {
      setIncentives([]);
      setSummaries([]);
      setNotifications([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [inc, sum, notifs] = await Promise.all([
        fetchOwnPublishedIncentives(),
        fetchOwnMonthlySummaries(),
        fetchOwnNotifications(),
      ]);
      setIncentives(inc);
      setSummaries(sum);
      setNotifications(notifs);
    } finally {
      setLoading(false);
    }
  }, [employeeLoginGate.allowed]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    setPhone(employeeProfile?.phone || '');
    setAddress(employeeProfile?.address || '');
    setEmergencyContact(employeeProfile?.emergencyContact || '');
  }, [employeeProfile]);

  const currentMonth = getCurrentMonthKeyIST();
  const prevMonth = getPreviousMonthKey(currentMonth);

  // Strictly partition Daily, Monthly, and Custom Period records
  const partitioned = useMemo(() => partitionEmployeeRecords(incentives), [incentives]);

  // Double-counting-safe current & previous month totals computed directly from partitioned published records
  const currentMonthAgg = useMemo(() => {
    if (!employeeProfile) return null;
    return aggregateEmployeeMonth(incentives, employeeProfile.employeeId, currentMonth);
  }, [incentives, employeeProfile, currentMonth]);

  const previousMonthAgg = useMemo(() => {
    if (!employeeProfile) return null;
    return aggregateEmployeeMonth(incentives, employeeProfile.employeeId, prevMonth);
  }, [incentives, employeeProfile, prevMonth]);

  const momDelta = useMemo(() => {
    const curr = currentMonthAgg?.grandTotalPaise || 0;
    const prev = previousMonthAgg?.grandTotalPaise || 0;
    const diff = curr - prev;
    const pct = prev > 0 ? Math.round((diff / prev) * 100) : curr > 0 ? 100 : 0;
    return { diff, pct };
  }, [currentMonthAgg, previousMonthAgg]);

  const availableMonths = useMemo(() => {
    const set = new Set<string>([currentMonth]);
    for (const s of summaries) set.add(s.monthKey);
    for (const i of incentives) set.add(i.monthKey);
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [summaries, incentives, currentMonth]);

  // Daily statements ONLY use DAILY records for the selected month
  const monthDailyRecords = useMemo(
    () => partitioned.dailyRecords.filter((r) => r.monthKey === selectedMonth),
    [partitioned.dailyRecords, selectedMonth],
  );

  // Monthly statements ONLY use MONTHLY records for the selected month
  const monthMonthlyRecords = useMemo(
    () => partitioned.monthlyRecords.filter((r) => r.monthKey === selectedMonth),
    [partitioned.monthlyRecords, selectedMonth],
  );

  // Custom period statements stay completely separate
  const monthCustomRecords = useMemo(
    () => partitioned.customPeriodRecords.filter((r) => r.monthKey === selectedMonth),
    [partitioned.customPeriodRecords, selectedMonth],
  );

  // Recompute double-counting-safe history across all available months
  const safeMonthlyHistory = useMemo(() => {
    if (!employeeProfile) return [];
    return availableMonths
      .map((monthKey) => aggregateEmployeeMonth(incentives, employeeProfile.employeeId, monthKey))
      .filter((agg) => agg.sourceType !== 'NO_DATA');
  }, [availableMonths, incentives, employeeProfile]);

  const latestRecord = incentives[0] || null;
  const unreadCount = notifications.filter((n) => !n.read).length;

  const maxHistoryPaise = useMemo(
    () => Math.max(1, ...safeMonthlyHistory.map((s) => s.grandTotalPaise)),
    [safeMonthlyHistory],
  );

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeProfile) return;
    setProfileSaving(true);
    setProfileMessage(null);
    try {
      await updateOwnEmployeeProfile(employeeProfile.employeeId, {
        phone,
        address,
        emergencyContact,
      });
      await refreshEmployeeProfile();
      setProfileMessage('Profile details updated successfully.');
    } finally {
      setProfileSaving(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setPwdMessage({ type: 'err', text: 'New password must be at least 8 characters.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwdMessage({ type: 'err', text: 'Passwords do not match.' });
      return;
    }
    setPwdSaving(true);
    setPwdMessage(null);
    try {
      await changeOwnPassword(newPassword);
      if (employeeProfile?.mustChangePassword) {
        await updateOwnEmployeeProfile(employeeProfile.employeeId, {
          phone: employeeProfile.phone || '',
          address: employeeProfile.address || '',
          emergencyContact: employeeProfile.emergencyContact || '',
          mustChangePassword: false,
        });
        await refreshEmployeeProfile();
      }
      setNewPassword('');
      setConfirmPassword('');
      setPwdMessage({ type: 'ok', text: 'Password updated successfully.' });
    } catch (err) {
      setPwdMessage({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Please sign out and sign in again before changing your password.',
      });
    } finally {
      setPwdSaving(false);
    }
  };

  const handleMarkRead = async (notificationId: string) => {
    await markNotificationRead(notificationId);
    setNotifications((prev) =>
      prev.map((n) => (n.notificationId === notificationId ? { ...n, read: true } : n)),
    );
  };

  // Strict Deactivated Employee Block (preserves history in DB, blocks login access until Super Admin reactivates)
  if (!employeeLoginGate.allowed) {
    const isDeactivated = employeeLoginGate.code === 'ACCOUNT_DEACTIVATED';
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-red-50 text-red-700 flex items-center justify-center mx-auto">
            <ShieldOff className="w-6 h-6" />
          </div>
          <h1 className="text-lg font-semibold text-slate-900">
            {isDeactivated
              ? 'Employee Account Deactivated'
              : 'Account Not Linked to Employee Master'}
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">{employeeLoginGate.message}</p>
          {isDeactivated && employeeProfile && (
            <p className="text-xs font-mono text-slate-500">
              Salesman No: {employeeProfile.employeeId} · Status: INACTIVE
            </p>
          )}
          <button
            type="button"
            onClick={logout}
            className="h-11 px-5 rounded-xl bg-slate-900 text-white text-sm font-medium cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  const renderRecordPeriodLine = (rec: PublishedIncentive) => {
    const norm = normalizeRecordPeriod(rec);
    const typeLabel = formatImportTypeLabel(norm.importType);
    const dateRange =
      norm.importType === 'DAILY'
        ? formatShortDate(norm.periodStart)
        : `${formatShortDate(norm.periodStart)} – ${formatShortDate(norm.periodEnd)}`;
    return { typeLabel, dateRange };
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-20 lg:pb-10">
      {/* Compact Top App Bar (56px) */}
      <header className="sticky top-0 z-30 h-14 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-full flex items-center justify-between gap-4">
          <div className="min-w-0">
            <span className="text-sm font-bold tracking-tight text-slate-900 whitespace-nowrap">
              House of Muktai
            </span>
          </div>

          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
            {(
              [
                ['home', 'Overview'],
                ['statements', 'Incentive Statements'],
                ['history', 'Monthly History'],
                ['profile', 'Profile'],
              ] as Array<[StaffTab, string]>
            ).map(([tab, label]) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`py-1 transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === tab
                    ? 'text-rose-900 border-b-2 border-rose-900'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          <button
            type="button"
            onClick={logout}
            className="min-h-[40px] px-3 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {employeeProfile!.mustChangePassword && (
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-sm text-amber-900">
              <strong>Action Required:</strong> Please update your initial administrator-issued
              password to keep your incentive account secure.
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className="h-10 px-4 rounded-lg bg-amber-900 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
            >
              Change Password
            </button>
          </div>
        )}

        {/* Identity Strip */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold text-slate-900">{employeeProfile!.fullName}</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              <span className="font-mono">{employeeProfile!.employeeId}</span> ·{' '}
              {employeeProfile!.branchName} · {employeeProfile!.designation}
            </p>
          </div>
          {unreadCount > 0 && (
            <span className="text-xs font-medium text-rose-900 inline-flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5" />
              {unreadCount} new incentive publish alert{unreadCount > 1 ? 's' : ''}
            </span>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="h-44 bg-white border border-slate-200 rounded-2xl animate-pulse" />
            <div className="h-44 bg-white border border-slate-200 rounded-2xl animate-pulse" />
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Monthly Total Hero Card (Double-Counting Safe) */}
                <section className="lg:col-span-7 bg-slate-900 text-white rounded-2xl p-6 space-y-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-slate-300 font-medium">
                        Monthly Incentive · {formatMonthLabel(currentMonth)}
                      </p>
                      <p className="text-3xl sm:text-4xl font-semibold font-mono tabular-nums mt-2">
                        {formatINRFromPaise(currentMonthAgg?.grandTotalPaise || 0)}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        {currentMonthAgg?.sourceType === 'MONTHLY_RECORD'
                          ? 'Source: Published Monthly Incentive'
                          : currentMonthAgg?.sourceType === 'DAILY_AGGREGATE'
                            ? `Source: Sum of ${currentMonthAgg.publishedDaysCount} Published Daily Record(s)`
                            : 'No published daily or monthly incentive yet'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-medium ${
                          momDelta.diff >= 0 ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {momDelta.diff >= 0 ? (
                          <TrendingUp className="w-3.5 h-3.5" />
                        ) : (
                          <TrendingDown className="w-3.5 h-3.5" />
                        )}
                        <span className="font-mono tabular-nums">
                          {momDelta.diff >= 0 ? '+' : ''}
                          {momDelta.pct}%
                        </span>
                      </span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        vs {formatMonthLabel(prevMonth)}
                      </p>
                    </div>
                  </div>

                  {/* 3 Separately Identifiable Incentive Components */}
                  <div className="pt-4 border-t border-slate-800 grid grid-cols-3 gap-3">
                    <div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {latestRecord?.component1Label || 'Incentive New Qty'}
                      </p>
                      <p className="text-sm sm:text-base font-mono tabular-nums font-medium mt-1">
                        {formatINRFromPaise(currentMonthAgg?.component1TotalPaise || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {latestRecord?.component2Label || 'Old Incentive'}
                      </p>
                      <p className="text-sm sm:text-base font-mono tabular-nums font-medium mt-1">
                        {formatINRFromPaise(currentMonthAgg?.component2TotalPaise || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {latestRecord?.component3Label || 'Incentive - 0.50%'}
                      </p>
                      <p className="text-sm sm:text-base font-mono tabular-nums font-medium mt-1">
                        {formatINRFromPaise(currentMonthAgg?.component3TotalPaise || 0)}
                      </p>
                    </div>
                  </div>
                </section>

                {/* Latest Published Statement Card */}
                <section className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-slate-900">
                      Latest Published Statement
                    </h2>
                    <button
                      type="button"
                      onClick={() => setActiveTab('statements')}
                      className="text-xs font-medium text-rose-900 hover:underline cursor-pointer"
                    >
                      View All
                    </button>
                  </div>

                  {latestRecord ? (
                    (() => {
                      const info = renderRecordPeriodLine(latestRecord);
                      return (
                        <div className="space-y-3">
                          <div className="flex items-baseline justify-between gap-2">
                            <div>
                              <p className="text-xs font-semibold text-rose-900">
                                {info.typeLabel}
                              </p>
                              <p className="text-xs text-slate-500 mt-0.5">{info.dateRange}</p>
                            </div>
                            <span className="text-xl font-semibold font-mono tabular-nums text-slate-900">
                              {formatINRFromPaise(latestRecord.totalPaise)}
                            </span>
                          </div>
                          <div className="divide-y divide-slate-100 text-xs pt-2 border-t border-slate-100">
                            <div className="py-2 flex justify-between">
                              <span className="text-slate-600">{latestRecord.component1Label}</span>
                              <span className="font-mono tabular-nums text-slate-900">
                                {formatINRFromPaise(latestRecord.component1Paise)}
                              </span>
                            </div>
                            <div className="py-2 flex justify-between">
                              <span className="text-slate-600">{latestRecord.component2Label}</span>
                              <span className="font-mono tabular-nums text-slate-900">
                                {formatINRFromPaise(latestRecord.component2Paise)}
                              </span>
                            </div>
                            <div className="py-2 flex justify-between">
                              <span className="text-slate-600">{latestRecord.component3Label}</span>
                              <span className="font-mono tabular-nums text-slate-900">
                                {formatINRFromPaise(latestRecord.component3Paise)}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })()
                  ) : (
                    <p className="text-sm text-slate-500 py-4">
                      No published incentives are available for your account yet.
                    </p>
                  )}
                </section>

                {/* Separate Custom Period Statements Notice if present */}
                {partitioned.customPeriodRecords.length > 0 && (
                  <section className="lg:col-span-12 bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="text-sm font-semibold text-slate-900">
                          Custom Period Incentive Statements
                        </h2>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Displayed separately with exact period dates (never mixed into daily or
                          monthly totals)
                        </p>
                      </div>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {partitioned.customPeriodRecords.slice(0, 4).map((rec) => {
                        const info = renderRecordPeriodLine(rec);
                        return (
                          <div
                            key={rec.recordId}
                            className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-4"
                          >
                            <div>
                              <p className="text-xs font-semibold text-rose-900">
                                {info.typeLabel}
                              </p>
                              <p className="text-sm font-medium text-slate-900">{info.dateRange}</p>
                            </div>
                            <span className="font-mono tabular-nums font-semibold text-slate-900">
                              {formatINRFromPaise(rec.totalPaise)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {/* Publish Notifications */}
                {notifications.length > 0 && (
                  <section className="lg:col-span-12 bg-white border border-slate-200 rounded-2xl p-6">
                    <h2 className="text-sm font-semibold text-slate-900 mb-4">
                      Recent Publish Notifications
                    </h2>
                    <div className="divide-y divide-slate-100">
                      {notifications.slice(0, 5).map((n) => (
                        <div
                          key={n.notificationId}
                          className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-4"
                        >
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slate-900">{n.title}</p>
                            <p className="text-xs text-slate-500 mt-0.5">{n.message}</p>
                          </div>
                          {!n.read ? (
                            <button
                              type="button"
                              onClick={() => handleMarkRead(n.notificationId)}
                              className="min-h-[36px] px-3 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              Mark Read
                            </button>
                          ) : (
                            <span className="text-xs text-slate-400 shrink-0">Read</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </section>
                )}
              </div>
            )}

            {activeTab === 'statements' && (
              <div className="space-y-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Published Incentive Statements
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Daily, Monthly, and Custom Period records are clearly labeled and kept
                      separate
                    </p>
                  </div>
                  <select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-800"
                  >
                    {availableMonths.map((m) => (
                      <option key={m} value={m}>
                        {formatMonthLabel(m)}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Monthly Incentive Statements (Never split across days) */}
                {monthMonthlyRecords.length > 0 && (
                  <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                    <div className="p-5 border-b border-slate-200 bg-slate-50/70">
                      <h3 className="text-sm font-semibold text-slate-900">Monthly Incentive</h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Full-month consolidated incentive statement (not split into daily rows)
                      </p>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {monthMonthlyRecords.map((rec) => {
                        const info = renderRecordPeriodLine(rec);
                        return (
                          <div key={rec.recordId} className="p-5 space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-xs font-semibold text-rose-900">
                                  {info.typeLabel}
                                </p>
                                <p className="text-sm font-semibold text-slate-900 mt-0.5">
                                  {info.dateRange}
                                </p>
                                <p className="text-xs text-slate-500">
                                  {rec.branchName}
                                  {rec.version > 1 ? ` · Revised v${rec.version}` : ''}
                                </p>
                              </div>
                              <p className="text-base font-semibold font-mono tabular-nums text-rose-900">
                                {formatINRFromPaise(rec.totalPaise)}
                              </p>
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
                              <div>
                                <p className="text-slate-500 truncate">{rec.component1Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component1Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component2Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component2Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component3Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component3Paise)}
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {/* Custom Period Incentive Statements */}
                {monthCustomRecords.length > 0 && (
                  <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                    <div className="p-5 border-b border-slate-200 bg-slate-50/70">
                      <h3 className="text-sm font-semibold text-slate-900">
                        Custom Period Incentive
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Total incentive for the exact custom date range shown
                      </p>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {monthCustomRecords.map((rec) => {
                        const info = renderRecordPeriodLine(rec);
                        return (
                          <div key={rec.recordId} className="p-5 space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-xs font-semibold text-rose-900">
                                  {info.typeLabel}
                                </p>
                                <p className="text-sm font-semibold text-slate-900 mt-0.5">
                                  {info.dateRange}
                                </p>
                                <p className="text-xs text-slate-500">
                                  {rec.branchName}
                                  {rec.version > 1 ? ` · Revised v${rec.version}` : ''}
                                </p>
                              </div>
                              <p className="text-base font-semibold font-mono tabular-nums text-rose-900">
                                {formatINRFromPaise(rec.totalPaise)}
                              </p>
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
                              <div>
                                <p className="text-slate-500 truncate">{rec.component1Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component1Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component2Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component2Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component3Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component3Paise)}
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {/* Daily Incentive Breakdown (Daily records ONLY) */}
                <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                  <div className="p-5 border-b border-slate-200 bg-slate-50/70">
                    <h3 className="text-sm font-semibold text-slate-900">
                      Daily Incentive Breakdown
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Individual published daily incentive records for{' '}
                      {formatMonthLabel(selectedMonth)}
                    </p>
                  </div>

                  {monthDailyRecords.length === 0 ? (
                    <div className="p-10 text-center text-sm text-slate-500">
                      No individual daily incentive records for {formatMonthLabel(selectedMonth)}.
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {monthDailyRecords.map((rec) => {
                        const info = renderRecordPeriodLine(rec);
                        return (
                          <div key={rec.recordId} className="p-5 space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-xs font-semibold text-rose-900">
                                  {info.typeLabel}
                                </p>
                                <p className="text-sm font-semibold text-slate-900 mt-0.5">
                                  {info.dateRange}
                                </p>
                                <p className="text-xs text-slate-500">
                                  {rec.branchName}
                                  {rec.version > 1 ? ` · Revised v${rec.version}` : ''}
                                </p>
                              </div>
                              <p className="text-base font-semibold font-mono tabular-nums text-rose-900">
                                {formatINRFromPaise(rec.totalPaise)}
                              </p>
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
                              <div>
                                <p className="text-slate-500 truncate">{rec.component1Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component1Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component2Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component2Paise)}
                                </p>
                              </div>
                              <div>
                                <p className="text-slate-500 truncate">{rec.component3Label}</p>
                                <p className="font-mono tabular-nums font-medium text-slate-800 mt-0.5">
                                  {formatINRFromPaise(rec.component3Paise)}
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </section>
              </div>
            )}

            {activeTab === 'history' && (
              <section className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6">
                <div>
                  <h2 className="text-base font-semibold text-slate-900">
                    Previous Months &amp; Incentive Growth
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Month-over-month comparison using double-counting-safe monthly totals
                  </p>
                </div>

                {safeMonthlyHistory.length === 0 ? (
                  <p className="text-sm text-slate-500 py-8 text-center">
                    Monthly history will appear here once incentives are published.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {safeMonthlyHistory.map((s, idx) => {
                      const prev = safeMonthlyHistory[idx + 1];
                      const delta = prev ? s.grandTotalPaise - prev.grandTotalPaise : null;
                      const widthPct = Math.max(
                        5,
                        Math.round((s.grandTotalPaise / maxHistoryPaise) * 100),
                      );
                      return (
                        <div key={s.monthKey} className="space-y-1.5">
                          <div className="flex items-center justify-between gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-slate-900">
                                {formatMonthLabel(s.monthKey)}
                              </span>
                              <span className="text-xs text-slate-500">
                                ·{' '}
                                {s.sourceType === 'MONTHLY_RECORD'
                                  ? 'Monthly Statement'
                                  : `${s.publishedDaysCount} daily records`}
                              </span>
                            </div>
                            <div className="flex items-center gap-3">
                              {delta !== null && (
                                <span
                                  className={`text-xs font-mono tabular-nums ${
                                    delta >= 0 ? 'text-emerald-700' : 'text-red-700'
                                  }`}
                                >
                                  {delta >= 0 ? '+' : ''}
                                  {formatINRFromPaise(delta)}
                                </span>
                              )}
                              <span className="font-mono tabular-nums font-semibold text-slate-900">
                                {formatINRFromPaise(s.grandTotalPaise)}
                              </span>
                            </div>
                          </div>
                          <div className="h-2.5 w-full bg-slate-100 rounded-sm overflow-hidden">
                            <div
                              className="h-full bg-rose-900 rounded-sm"
                              style={{ width: `${widthPct}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            )}

            {activeTab === 'profile' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <form
                  onSubmit={handleProfileSave}
                  className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
                >
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">My Profile Details</h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Salesman No, Login ID, Branch, and Active/Inactive status are managed by Super
                      Admin.
                    </p>
                  </div>

                  {profileMessage && (
                    <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
                      {profileMessage}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-slate-500">Salesman No</span>
                      <p className="font-mono font-semibold text-slate-900 mt-0.5">
                        {employeeProfile!.employeeId}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-500">Login ID</span>
                      <p className="font-mono font-semibold text-slate-900 mt-0.5">
                        {employeeProfile!.loginId}
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Residential Address
                    </label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Emergency Contact
                    </label>
                    <input
                      type="text"
                      value={emergencyContact}
                      onChange={(e) => setEmergencyContact(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={profileSaving}
                    className="w-full h-11 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium disabled:opacity-60 cursor-pointer"
                  >
                    {profileSaving ? 'Saving...' : 'Update Permitted Profile Info'}
                  </button>
                </form>

                <form
                  onSubmit={handlePasswordChange}
                  className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
                >
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-rose-900" />
                    <h2 className="text-base font-semibold text-slate-900">Change Password</h2>
                  </div>
                  <p className="text-xs text-slate-500">
                    Use at least 8 characters. Do not share your credentials with coworkers.
                  </p>

                  {pwdMessage && (
                    <div
                      className={`p-3 rounded-lg border text-xs ${
                        pwdMessage.type === 'ok'
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-red-50 border-red-200 text-red-800'
                      }`}
                    >
                      {pwdMessage.text}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={8}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={8}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={pwdSaving}
                    className="w-full h-11 rounded-xl bg-rose-900 hover:bg-rose-950 text-white text-sm font-medium disabled:opacity-60 cursor-pointer"
                  >
                    {pwdSaving ? 'Updating Password...' : 'Update Password'}
                  </button>
                </form>
              </div>
            )}
          </>
        )}
      </main>

      {/* Mobile Bottom Tab Bar */}
      <nav
        aria-label="Employee Navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-4 h-16">
          {(
            [
              ['home', 'Home', Home],
              ['statements', 'Statements', Calendar],
              ['history', 'History', TrendingUp],
              ['profile', 'Profile', User],
            ] as Array<[StaffTab, string, React.ComponentType<{ className?: string }>]>
          ).map(([tab, label, Icon]) => {
            const active = activeTab === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`flex flex-col items-center justify-center min-h-[44px] ${
                  active ? 'text-rose-900' : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium mt-1">{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
