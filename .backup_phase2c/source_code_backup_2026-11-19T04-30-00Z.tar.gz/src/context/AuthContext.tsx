import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updatePassword,
  type User,
} from 'firebase/auth';
import {
  auth,
  BOOTSTRAPPED_ADMIN_EMAIL,
  googleProvider,
  loginIdToAuthEmail,
} from '../lib/firebase';
import { fetchOwnEmployeeProfile } from '../services/incentiveService';
import type { Employee } from '../types/incentive';

import { canEmployeeLogin, type EmployeeLoginGateResult } from '../lib/incentiveEngine';

export type PortalMode = 'admin' | 'staff';

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  isSuperAdmin: boolean;
  employeeProfile: Employee | null;
  employeeLoginGate: EmployeeLoginGateResult;
  portalMode: PortalMode;
  setPortalMode: (mode: PortalMode) => void;
  signInAdminWithGoogle: () => Promise<void>;
  signInEmployeeWithLoginId: (loginId: string, password: string) => Promise<void>;
  signInEmployeeWithGoogle: () => Promise<void>;
  changeOwnPassword: (newPassword: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshEmployeeProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function detectInitialPortalMode(): PortalMode {
  if (typeof window !== 'undefined') {
    const host = window.location.hostname.toLowerCase();
    if (host.startsWith('staff.')) return 'staff';
    if (host.startsWith('admin.')) return 'admin';
    const params = new URLSearchParams(window.location.search);
    if (params.get('portal') === 'staff') return 'staff';
  }
  return 'admin';
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [employeeProfile, setEmployeeProfile] = useState<Employee | null>(null);
  const [portalMode, setPortalMode] = useState<PortalMode>(detectInitialPortalMode);

  const isSuperAdmin = Boolean(
    user &&
      user.emailVerified &&
      user.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase(),
  );

  const loadProfile = async (currentUser: User | null) => {
    if (!currentUser) {
      setEmployeeProfile(null);
      return;
    }
    try {
      const emp = await fetchOwnEmployeeProfile();
      setEmployeeProfile(emp);
    } catch {
      setEmployeeProfile(null);
    }
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        const isAdminAccount =
          nextUser.emailVerified &&
          nextUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();
        if (!isAdminAccount) {
          await loadProfile(nextUser);
          setPortalMode('staff');
        } else {
          setEmployeeProfile(null);
        }
      } else {
        setEmployeeProfile(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const signInAdminWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const signInEmployeeWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const signInEmployeeWithLoginId = async (loginId: string, password: string) => {
    const authEmail = loginIdToAuthEmail(loginId);
    await signInWithEmailAndPassword(auth, authEmail, password);
  };

  const changeOwnPassword = async (newPassword: string) => {
    if (!auth.currentUser) throw new Error('Not signed in.');
    await updatePassword(auth.currentUser, newPassword);
  };

  const logout = async () => {
    await signOut(auth);
    setEmployeeProfile(null);
  };

  const refreshEmployeeProfile = async () => {
    await loadProfile(auth.currentUser);
  };

  const employeeLoginGate = canEmployeeLogin(employeeProfile);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isSuperAdmin,
        employeeProfile,
        employeeLoginGate,
        portalMode,
        setPortalMode,
        signInAdminWithGoogle,
        signInEmployeeWithLoginId,
        signInEmployeeWithGoogle,
        changeOwnPassword,
        logout,
        refreshEmployeeProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
