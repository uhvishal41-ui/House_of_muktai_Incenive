export type UserRole = 'SUPER_ADMIN' | 'BRANCH_MANAGER' | 'EMPLOYEE';

export type ImportType = 'DAILY' | 'MONTHLY' | 'CUSTOM_PERIOD';

export interface Branch {
  branchId: string;
  branchCode: string;
  branchName: string;
  city: string;
  managerName?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Employee {
  employeeId: string;
  loginId: string;
  authEmail: string;
  linkedGoogleEmail?: string;
  authUid?: string;
  fullName: string;
  branchId: string;
  branchName: string;
  designation: string;
  phone?: string;
  address?: string;
  emergencyContact?: string;
  role: 'EMPLOYEE' | 'BRANCH_MANAGER';
  status: 'ACTIVE' | 'INACTIVE';
  mustChangePassword: boolean;
  credentialsProvisioned: boolean;
  createdAt: string;
  updatedAt: string;
}

export type BatchStatus = 'UPLOADED' | 'VALIDATED' | 'APPROVED' | 'PUBLISHED' | 'REJECTED';

export interface ComponentLabels {
  component1: string;
  component2: string;
  component3: string;
}

export interface ImportBatch {
  batchId: string;
  fileName: string;
  fileSha256: string;
  importType: ImportType;
  periodStart: string;
  periodEnd: string;
  businessDate: string;
  status: BatchStatus;
  totalRows: number;
  validRows: number;
  errorRows: number;
  duplicateRows: number;
  correctionRows: number;
  overlapRows?: number;
  branchTransferRows?: number;
  skippedBlankRows?: number;
  skippedSummaryRows?: number;
  totalIncentivePaise: number;
  componentLabels?: ComponentLabels;
  uploadedByUid: string;
  uploadedByEmail: string;
  approvedByEmail?: string;
  publishedByEmail?: string;
  rejectionReason?: string;
  correctionNote?: string;
  createdAt: string;
  updatedAt: string;
}

export type RowValidationStatus =
  | 'VALID'
  | 'ERROR'
  | 'DUPLICATE_IN_FILE'
  | 'EXISTS_PUBLISHED'
  | 'PERIOD_OVERLAP'
  | 'BRANCH_TRANSFER';

export type RowResolution = 'PUBLISH_NEW' | 'SKIP' | 'CORRECTION';

export interface ImportBatchRow {
  rowId: string;
  batchId: string;
  rowNumber: number;
  importType: ImportType;
  periodStart: string;
  periodEnd: string;
  businessDate: string;
  employeeId: string;
  employeeName?: string;
  branchId?: string;
  branchName?: string;
  component1Paise: number;
  component2Paise: number;
  component3Paise: number;
  totalPaise: number;
  validationStatus: RowValidationStatus;
  resolution: RowResolution;
  correctionReason?: string;
  errorMessage?: string;
  createdAt: string;
}

export interface PublishedIncentive {
  recordId: string;
  importType?: ImportType;
  periodStart?: string;
  periodEnd?: string;
  businessDate: string;
  monthKey: string;
  employeeId: string;
  authUid: string;
  employeeName: string;
  branchId: string;
  branchName: string;
  component1Label: string;
  component2Label: string;
  component3Label: string;
  component1Paise: number;
  component2Paise: number;
  component3Paise: number;
  totalPaise: number;
  status: 'PUBLISHED';
  version: number;
  batchId: string;
  correctionReason?: string;
  publishedAt: string;
  publishedByEmail: string;
}

export interface IncentiveVersion {
  versionId: string;
  recordId: string;
  importType?: ImportType;
  periodStart?: string;
  periodEnd?: string;
  businessDate: string;
  employeeId: string;
  branchId: string;
  previousVersion: number;
  newVersion: number;
  previousComponent1Paise: number;
  previousComponent2Paise: number;
  previousComponent3Paise: number;
  previousTotalPaise: number;
  newComponent1Paise: number;
  newComponent2Paise: number;
  newComponent3Paise: number;
  newTotalPaise: number;
  correctionReason: string;
  batchId: string;
  correctedByEmail: string;
  archivedAt: string;
}

export type MonthlySummarySourceType = 'DAILY_AGGREGATE' | 'MONTHLY_RECORD' | 'NO_DATA';

export interface MonthlySummary {
  summaryId: string;
  employeeId: string;
  authUid: string;
  employeeName: string;
  branchId: string;
  branchName: string;
  monthKey: string;
  sourceType?: MonthlySummarySourceType;
  component1TotalPaise: number;
  component2TotalPaise: number;
  component3TotalPaise: number;
  grandTotalPaise: number;
  publishedDaysCount: number;
  updatedAt: string;
}

export interface AuditLog {
  logId: string;
  action: string;
  actorUid: string;
  actorEmail: string;
  actorRole: string;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt: string;
}

export interface EmployeeNotification {
  notificationId: string;
  employeeId: string;
  authUid: string;
  title: string;
  message: string;
  importType?: ImportType;
  periodStart?: string;
  periodEnd?: string;
  businessDate: string;
  batchId: string;
  read: boolean;
  createdAt: string;
  readAt?: string;
}

export interface ExcelColumnMapping {
  businessDate: string;
  employeeId: string;
  employeeName: string;
  branchCode: string;
  component1: string;
  component2: string;
  component3: string;
}

export interface ParsedExcelRow {
  rowNumber: number;
  raw: Record<string, string | number | null>;
}

export interface ExcelParseResponse {
  fileName: string;
  fileSha256: string;
  sheetName: string;
  availableSheets: string[];
  headerRowNumber: number;
  reportTitle: string;
  reportDateRangeText: string;
  importType: ImportType | null;
  periodStart: string | null;
  periodEnd: string | null;
  detectedFromDate: string | null;
  detectedToDate: string | null;
  dateValidationError: string | null;
  rawTotalRows: number;
  skippedBlankRows: number;
  skippedSummaryRows: number;
  headers: string[];
  excludedSalesColumns: string[];
  suggestedMapping: ExcelColumnMapping;
  totalRows: number;
  rows: ParsedExcelRow[];
}
