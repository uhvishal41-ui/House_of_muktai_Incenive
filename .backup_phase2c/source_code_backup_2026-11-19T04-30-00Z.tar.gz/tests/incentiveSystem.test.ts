import assert from 'node:assert/strict';
import http from 'node:http';
import test from 'node:test';
import ExcelJS from 'exceljs';
import type { NextFunction, Response } from 'express';
import { createExpressApp } from '../server.ts';
import type { AuthenticatedRequest } from '../server/authMiddleware.ts';
import {
  buildSampleTemplateWorkbook,
  parseExcelBuffer,
} from '../server/excelEngine.ts';
import {
  aggregateEmployeeMonth,
  applyPublishedCorrection,
  authorizeEmployeeStatusChange,
  canEmployeeLogin,
  getIncentiveRecordKey,
  partitionEmployeeRecords,
  validateImportBatch,
} from '../src/lib/incentiveEngine.ts';
import type {
  Branch,
  Employee,
  PublishedIncentive,
  UserRole,
} from '../src/types/incentive.ts';

// --- Shared Realistic House of Muktai ERP Fixtures ---
const BRANCHES: Branch[] = [
  {
    branchId: 'BARAMATI_MIDC',
    branchCode: 'BARAMATI_MIDC',
    branchName: 'BARAMATI MIDC',
    city: 'Baramati',
    active: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
  {
    branchId: 'BARAMATI_MOTIBAG',
    branchCode: 'BARAMATI_MOTIBAG',
    branchName: 'BARAMATI MOTIBAG',
    city: 'Baramati',
    active: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
  {
    branchId: 'BEED',
    branchCode: 'BEED',
    branchName: 'BEED',
    city: 'Beed',
    active: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
];

const EMPLOYEES: Employee[] = [
  {
    employeeId: '459',
    loginId: 'HOM459',
    authEmail: 'hom459@staff.homfash.internal',
    authUid: 'uid-emp-459',
    fullName: 'Anita Popat Shingade',
    branchId: 'BARAMATI_MIDC',
    branchName: 'BARAMATI MIDC',
    designation: 'Sales Executive',
    role: 'EMPLOYEE',
    status: 'ACTIVE',
    mustChangePassword: false,
    credentialsProvisioned: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
  {
    employeeId: '355',
    loginId: 'HOM355',
    authEmail: 'hom355@staff.homfash.internal',
    authUid: 'uid-emp-355',
    fullName: 'Asha Abaji Chavan',
    branchId: 'BARAMATI_MOTIBAG',
    branchName: 'BARAMATI MOTIBAG',
    designation: 'Sales Executive',
    role: 'EMPLOYEE',
    status: 'ACTIVE',
    mustChangePassword: false,
    credentialsProvisioned: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
  {
    employeeId: '2432',
    loginId: 'HOM2432',
    authEmail: 'hom2432@staff.homfash.internal',
    authUid: 'uid-emp-2432',
    fullName: 'Ambrapali Shivaji Veer',
    branchId: 'BEED',
    branchName: 'BEED',
    designation: 'Sales Executive',
    role: 'EMPLOYEE',
    status: 'INACTIVE',
    mustChangePassword: false,
    credentialsProvisioned: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  },
];

function makePublishedRecord(overrides: Partial<PublishedIncentive>): PublishedIncentive {
  const importType = overrides.importType || 'DAILY';
  const periodStart = overrides.periodStart || overrides.businessDate || '2026-11-18';
  const periodEnd = overrides.periodEnd || periodStart;
  const employeeId = overrides.employeeId || '459';
  const c1 = overrides.component1Paise ?? 81600;
  const c2 = overrides.component2Paise ?? 1200;
  const c3 = overrides.component3Paise ?? 5100;
  return {
    recordId:
      overrides.recordId || getIncentiveRecordKey(importType, periodStart, periodEnd, employeeId),
    importType,
    periodStart,
    periodEnd,
    businessDate: importType === 'DAILY' ? periodStart : periodEnd,
    monthKey: periodStart.slice(0, 7),
    employeeId,
    authUid: overrides.authUid || 'uid-emp-459',
    employeeName: overrides.employeeName || 'Anita Popat Shingade',
    branchId: overrides.branchId || 'BARAMATI_MIDC',
    branchName: overrides.branchName || 'BARAMATI MIDC',
    component1Label: 'Incentive New Quantity Wise',
    component2Label: 'Old Incentive',
    component3Label: 'Incentive - 0.50%',
    component1Paise: c1,
    component2Paise: c2,
    component3Paise: c3,
    totalPaise: c1 + c2 + c3,
    status: 'PUBLISHED',
    version: overrides.version ?? 1,
    batchId: overrides.batchId || 'BATCH_TEST_1',
    publishedAt: overrides.publishedAt || '2026-11-18T10:00:00.000Z',
    publishedByEmail: 'uhvishal41@gmail.com',
  };
}

// =========================================================================
// TEST 1: Daily Excel Import Detection & Parsing
// =========================================================================
test('01. Daily Excel import (18-11-2026 To 18-11-2026) detects DAILY and validates exact totals', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 816,
        component2: 12,
        component3: 51,
      },
    ],
    '2026-11-18',
  );

  const parsed = await parseExcelBuffer(buf, 'daily-18-11-2026.xlsx');
  assert.equal(parsed.importType, 'DAILY');
  assert.equal(parsed.periodStart, '2026-11-18');
  assert.equal(parsed.periodEnd, '2026-11-18');
  assert.equal(parsed.dateValidationError, null);

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.canStage, true);
  assert.equal(val.metrics.detectedImportType, 'DAILY');
  assert.equal(val.metrics.validEmployeeRows, 1);
  assert.equal(val.rows[0].recordKey, '2026-11-18_459');
  assert.equal(val.rows[0].totalPaise, 87900); // 816 + 12 + 51 = ₹879.00
});

// =========================================================================
// TEST 2: Monthly Excel Import Detection & Logical Separation
// =========================================================================
test('02. Monthly Excel import (01-10-2026 To 31-10-2026) detects MONTHLY and never creates artificial daily records', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-10-01',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 8160,
        component2: 120,
        component3: 510,
      },
    ],
    '2026-10-31',
  );

  const parsed = await parseExcelBuffer(buf, 'oct-2026-monthly.xlsx');
  assert.equal(parsed.importType, 'MONTHLY');
  assert.equal(parsed.periodStart, '2026-10-01');
  assert.equal(parsed.periodEnd, '2026-10-31');

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.canStage, true);
  assert.equal(val.metrics.detectedImportType, 'MONTHLY');
  assert.equal(val.rows.length, 1); // Single monthly record, NOT 31 artificial daily rows
  assert.equal(val.rows[0].recordKey, 'MONTHLY_2026-10-01_2026-10-31_459');

  const monthlyRec = makePublishedRecord({
    importType: 'MONTHLY',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-31',
    component1Paise: 816000,
    component2Paise: 12000,
    component3Paise: 51000,
  });
  const parts = partitionEmployeeRecords([monthlyRec]);
  assert.equal(parts.dailyRecords.length, 0);
  assert.equal(parts.monthlyRecords.length, 1);
  assert.equal(parts.customPeriodRecords.length, 0);
});

// =========================================================================
// TEST 3: Custom Period Excel Import Detection
// =========================================================================
test('03. Custom Period Excel import (01-11-2026 To 15-11-2026) detects CUSTOM_PERIOD with exact start/end', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-01',
    [
      {
        branchName: 'BARAMATI MOTIBAG',
        salesPersonName: 'ASHA ABAJI CHAVAN',
        salesmanNo: '355',
        component1: 1713,
        component2: 341,
        component3: 125,
      },
    ],
    '2026-11-15',
  );

  const parsed = await parseExcelBuffer(buf, 'nov-first-half.xlsx');
  assert.equal(parsed.importType, 'CUSTOM_PERIOD');
  assert.equal(parsed.periodStart, '2026-11-01');
  assert.equal(parsed.periodEnd, '2026-11-15');

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.canStage, true);
  assert.equal(val.rows[0].recordKey, 'CUSTOM_PERIOD_2026-11-01_2026-11-15_355');
  assert.equal(val.rows[0].totalPaise, 217900);
});

// =========================================================================
// TEST 4: Missing Banner Date Blocked
// =========================================================================
test('04. Missing Excel banner date is rejected and blocks staging', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 500,
        component2: 0,
        component3: 0,
      },
    ],
    '2026-11-18',
    '', // Empty date banner cell
  );

  const parsed = await parseExcelBuffer(buf, 'missing-banner.xlsx');
  assert.equal(parsed.importType, null);
  assert.ok(parsed.dateValidationError);

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.period.valid, false);
  assert.equal(val.period.errorCode, 'MISSING_BANNER_DATE');
  assert.equal(val.canStage, false);
});

// =========================================================================
// TEST 5: Invalid Date Range (start > end & impossible calendar date)
// =========================================================================
test('05. Invalid date range (start > end and invalid calendar date) is rejected and blocks staging', async () => {
  const reversedBuf = await buildSampleTemplateWorkbook(
    '2026-11-20',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 500,
        component2: 0,
        component3: 0,
      },
    ],
    '2026-11-10',
  );
  const parsedRev = await parseExcelBuffer(reversedBuf, 'reversed-dates.xlsx');
  assert.equal(parsedRev.importType, null);
  assert.match(parsedRev.dateValidationError || '', /after end date/i);

  const valRev = validateImportBatch({
    periodStart: parsedRev.periodStart,
    periodEnd: parsedRev.periodEnd,
    rawBannerDateText: parsedRev.reportDateRangeText,
    rawTotalRows: parsedRev.rawTotalRows,
    skippedBlankRows: parsedRev.skippedBlankRows,
    skippedSummaryRows: parsedRev.skippedSummaryRows,
    rows: parsedRev.rows,
    mapping: parsedRev.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });
  assert.equal(valRev.period.errorCode, 'INVALID_DATE_RANGE');
  assert.equal(valRev.canStage, false);

  // Impossible date: 31-02-2026
  const badCalBuf = await buildSampleTemplateWorkbook(
    '2026-02-01',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 500,
        component2: 0,
        component3: 0,
      },
    ],
    '2026-02-01',
    'As On :-01-02-2026 To 31-02-2026',
  );
  const parsedBadCal = await parseExcelBuffer(badCalBuf, 'impossible-feb31.xlsx');
  assert.equal(parsedBadCal.importType, null);
  assert.ok(parsedBadCal.dateValidationError);
});

// =========================================================================
// TEST 6: Blank Rows & Grand Total / Subtotal Rows Skipped Separately
// =========================================================================
test('06. Blank rows and Grand Total / Subtotal rows are skipped and counted separately', async () => {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet('Final Report');
  sheet.mergeCells('A1:B1');
  sheet.getCell('A1').value = 'Final Report incentive All Branches';
  sheet.mergeCells('C1:F1');
  sheet.getCell('C1').value = 'As On :-18-11-2026 To 18-11-2026';
  sheet.addRow([
    'NAME',
    'Sales Person Name',
    'Salesman No',
    'Incentive New Quantity Wise',
    'Old Incentive',
    'Incentive - 0.50%',
  ]);
  sheet.addRow(['BARAMATI MIDC', 'ANITA POPAT SHINGADE', 459, 816, 12, 51]);
  sheet.addRow(['BARAMATI MIDC', '(blank)', '(blank)', 0, 0, 0]);
  sheet.addRow(['BARAMATI MIDC', 'Subtotal', '', 816, 12, 51]);
  sheet.addRow(['BARAMATI MOTIBAG', '(blank)', '(blank)', 0, 0, 0]);
  sheet.addRow(['Grand Total', '', '', 816, 12, 51]);

  const buffer = Buffer.from(await wb.xlsx.writeBuffer());
  const parsed = await parseExcelBuffer(buffer, 'with-blanks-and-totals.xlsx');

  assert.equal(parsed.rawTotalRows, 5);
  assert.equal(parsed.skippedBlankRows, 2);
  assert.equal(parsed.skippedSummaryRows, 2);
  assert.equal(parsed.totalRows, 1);
  assert.equal(parsed.rows[0].raw['Salesman No'], 459);
});

// =========================================================================
// TEST 7: Duplicate Daily Import Blocked From Silent Overwrite
// =========================================================================
test('07. Duplicate DAILY import is flagged EXISTS_PUBLISHED and defaults to SKIP', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 900,
        component2: 10,
        component3: 40,
      },
    ],
    '2026-11-18',
  );
  const parsed = await parseExcelBuffer(buf, 'dup-daily.xlsx');
  const existing = makePublishedRecord({
    importType: 'DAILY',
    periodStart: '2026-11-18',
    periodEnd: '2026-11-18',
    employeeId: '459',
  });

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [existing],
  });

  assert.equal(val.rows[0].validationStatus, 'EXISTS_PUBLISHED');
  assert.equal(val.rows[0].resolution, 'SKIP');
  assert.equal(val.metrics.duplicateRecords, 1);
  assert.equal(val.canStage, false);
});

// =========================================================================
// TEST 8: Duplicate Monthly Import Blocked From Silent Overwrite
// =========================================================================
test('08. Duplicate MONTHLY import is flagged EXISTS_PUBLISHED and blocked from silent overwrite', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-10-01',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 8160,
        component2: 120,
        component3: 510,
      },
    ],
    '2026-10-31',
  );
  const parsed = await parseExcelBuffer(buf, 'dup-monthly.xlsx');
  const existing = makePublishedRecord({
    importType: 'MONTHLY',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-31',
    employeeId: '459',
    component1Paise: 816000,
    component2Paise: 12000,
    component3Paise: 51000,
  });

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [existing],
  });

  assert.equal(val.rows[0].validationStatus, 'EXISTS_PUBLISHED');
  assert.equal(val.rows[0].resolution, 'SKIP');
  assert.equal(val.metrics.existingPublishedRecords, 1);
});

// =========================================================================
// TEST 9: Duplicate Custom Period Import Blocked From Silent Overwrite
// =========================================================================
test('09. Duplicate CUSTOM_PERIOD import is flagged EXISTS_PUBLISHED and blocked from silent overwrite', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-01',
    [
      {
        branchName: 'BARAMATI MOTIBAG',
        salesPersonName: 'ASHA ABAJI CHAVAN',
        salesmanNo: '355',
        component1: 1713,
        component2: 341,
        component3: 125,
      },
    ],
    '2026-11-15',
  );
  const parsed = await parseExcelBuffer(buf, 'dup-custom.xlsx');
  const existing = makePublishedRecord({
    importType: 'CUSTOM_PERIOD',
    periodStart: '2026-11-01',
    periodEnd: '2026-11-15',
    employeeId: '355',
    authUid: 'uid-emp-355',
    employeeName: 'Asha Abaji Chavan',
    branchId: 'BARAMATI_MOTIBAG',
    branchName: 'BARAMATI MOTIBAG',
  });

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [existing],
  });

  assert.equal(val.rows[0].validationStatus, 'EXISTS_PUBLISHED');
  assert.equal(val.rows[0].resolution, 'SKIP');
});

// =========================================================================
// TEST 10: Daily Import Overlapping Existing Published Monthly Import
// =========================================================================
test('10. DAILY import overlapping existing published MONTHLY record triggers PERIOD_OVERLAP and blocks publish', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-10-15',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 500,
        component2: 20,
        component3: 30,
      },
    ],
    '2026-10-15',
  );
  const parsed = await parseExcelBuffer(buf, 'daily-inside-monthly.xlsx');
  const existingMonthly = makePublishedRecord({
    importType: 'MONTHLY',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-31',
    employeeId: '459',
  });

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [existingMonthly],
  });

  assert.equal(val.rows[0].validationStatus, 'PERIOD_OVERLAP');
  assert.equal(val.hasUnresolvedOverlaps, true);
  assert.equal(val.metrics.periodOverlapWarnings, 1);
  assert.equal(val.canStage, false);
});

// =========================================================================
// TEST 11: Monthly Import Overlapping Existing Published Daily Import
// =========================================================================
test('11. MONTHLY import overlapping existing published DAILY record triggers PERIOD_OVERLAP and blocks publish', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-01',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 9000,
        component2: 100,
        component3: 400,
      },
    ],
    '2026-11-30',
  );
  const parsed = await parseExcelBuffer(buf, 'monthly-over-daily.xlsx');
  const existingDaily = makePublishedRecord({
    importType: 'DAILY',
    periodStart: '2026-11-18',
    periodEnd: '2026-11-18',
    employeeId: '459',
  });

  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [existingDaily],
  });

  assert.equal(val.rows[0].validationStatus, 'PERIOD_OVERLAP');
  assert.equal(val.hasUnresolvedOverlaps, true);
  assert.equal(val.canStage, false);
});

// =========================================================================
// TEST 12: Custom Period Overlapping Existing Daily / Monthly / Custom Period
// =========================================================================
test('12. CUSTOM_PERIOD overlapping existing DAILY, MONTHLY, or CUSTOM_PERIOD triggers PERIOD_OVERLAP', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-10',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 3000,
        component2: 100,
        component3: 200,
      },
    ],
    '2026-11-20',
  );
  const parsed = await parseExcelBuffer(buf, 'custom-overlap.xlsx');

  const scenarios: PublishedIncentive[] = [
    makePublishedRecord({ importType: 'DAILY', periodStart: '2026-11-15', periodEnd: '2026-11-15' }),
    makePublishedRecord({ importType: 'MONTHLY', periodStart: '2026-11-01', periodEnd: '2026-11-30' }),
    makePublishedRecord({ importType: 'CUSTOM_PERIOD', periodStart: '2026-11-01', periodEnd: '2026-11-15' }),
  ];

  for (const existing of scenarios) {
    const val = validateImportBatch({
      periodStart: parsed.periodStart,
      periodEnd: parsed.periodEnd,
      rawBannerDateText: parsed.reportDateRangeText,
      rawTotalRows: parsed.rawTotalRows,
      skippedBlankRows: parsed.skippedBlankRows,
      skippedSummaryRows: parsed.skippedSummaryRows,
      rows: parsed.rows,
      mapping: parsed.suggestedMapping,
      branches: BRANCHES,
      employees: EMPLOYEES,
      publishedIncentives: [existing],
    });
    assert.equal(
      val.rows[0].validationStatus,
      'PERIOD_OVERLAP',
      `Expected PERIOD_OVERLAP against ${existing.importType}`,
    );
    assert.equal(val.canStage, false);
  }
});

// =========================================================================
// TEST 13: Double-Counting-Safe Monthly Reporting Aggregation
// =========================================================================
test('13. Monthly reporting aggregation NEVER double counts Daily + Monthly or adds Custom Period into monthly totals', () => {
  const daily1 = makePublishedRecord({
    importType: 'DAILY',
    periodStart: '2026-10-05',
    periodEnd: '2026-10-05',
    component1Paise: 10000,
    component2Paise: 2000,
    component3Paise: 3000,
  });
  const daily2 = makePublishedRecord({
    importType: 'DAILY',
    periodStart: '2026-10-06',
    periodEnd: '2026-10-06',
    component1Paise: 20000,
    component2Paise: 1000,
    component3Paise: 4000,
  });
  const customHalf = makePublishedRecord({
    importType: 'CUSTOM_PERIOD',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-15',
    component1Paise: 50000,
    component2Paise: 5000,
    component3Paise: 5000,
  });
  const monthlyFull = makePublishedRecord({
    importType: 'MONTHLY',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-31',
    component1Paise: 100000,
    component2Paise: 10000,
    component3Paise: 10000,
  });

  // Case A: Daily records + Custom Period -> sums ONLY Daily records (40000 paise), excludes Custom Period
  const aggDailyOnly = aggregateEmployeeMonth([daily1, daily2, customHalf], '459', '2026-10');
  assert.equal(aggDailyOnly.sourceType, 'DAILY_AGGREGATE');
  assert.equal(aggDailyOnly.grandTotalPaise, 40000);
  assert.equal(aggDailyOnly.publishedDaysCount, 2);
  assert.equal(aggDailyOnly.customPeriodRecordsExcludedFromMonthSum, 1);

  // Case B: Even if both Monthly and Daily existed -> NEVER adds them together (uses Monthly only = 120000 paise)
  const aggNoDouble = aggregateEmployeeMonth(
    [daily1, daily2, customHalf, monthlyFull],
    '459',
    '2026-10',
  );
  assert.equal(aggNoDouble.sourceType, 'MONTHLY_RECORD');
  assert.equal(aggNoDouble.grandTotalPaise, 120000);
  assert.equal(aggNoDouble.overlapAnomalyDetected, true);
});

// =========================================================================
// TEST 14: Match Employee Strictly By Salesman No Even On Name Change
// =========================================================================
test('14. Existing employee matches strictly by Salesman No even when Sales Person Name spelling changes', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'ANITA P. SHINGADE (UPDATED)',
        salesmanNo: '459',
        component1: 500,
        component2: 50,
        component3: 25,
      },
    ],
    '2026-11-18',
  );
  const parsed = await parseExcelBuffer(buf, 'name-spelling-change.xlsx');
  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.metrics.newEmployeeCandidates, 0);
  assert.equal(val.metrics.existingEmployees, 1);
  assert.equal(val.rows[0].validationStatus, 'VALID');
  assert.equal(val.rows[0].employeeId, '459');
  assert.equal(val.rows[0].employeeName, 'Anita Popat Shingade');
});

// =========================================================================
// TEST 15: Branch Transfer Warning (Never Silently Overwrites Branch)
// =========================================================================
test('15. Existing Salesman No under different branch triggers BRANCH_TRANSFER warning without silent overwrite', async () => {
  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BEED', // Master has BARAMATI MIDC for Salesman No 459
        salesPersonName: 'ANITA POPAT SHINGADE',
        salesmanNo: '459',
        component1: 700,
        component2: 0,
        component3: 30,
      },
    ],
    '2026-11-18',
  );
  const parsed = await parseExcelBuffer(buf, 'branch-transfer.xlsx');
  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: EMPLOYEES,
    publishedIncentives: [],
  });

  assert.equal(val.rows[0].validationStatus, 'BRANCH_TRANSFER');
  assert.equal(val.rows[0].resolution, 'SKIP');
  assert.equal(val.metrics.branchTransferWarnings, 1);
  assert.equal(val.branchTransfers.length, 1);
  assert.equal(val.branchTransfers[0].masterBranchName, 'BARAMATI MIDC');
  assert.equal(val.branchTransfers[0].excelBranchName, 'BEED');
  // Master employee record remains unchanged until Super Admin approves
  assert.equal(EMPLOYEES[0].branchId, 'BARAMATI_MIDC');
});

// =========================================================================
// TEST 16: SMPL Candidate Visibility Without Auto-Deactivation
// =========================================================================
test('16. SMPL rows are flagged as SMPL candidates for review and NEVER auto-deactivated or auto-status-flipped', async () => {
  const activeSmplEmployee: Employee = {
    employeeId: '809',
    loginId: 'HOM809',
    authEmail: 'hom809@staff.homfash.internal',
    authUid: 'uid-emp-809',
    fullName: 'SMPL Baramati',
    branchId: 'BARAMATI_MIDC',
    branchName: 'BARAMATI MIDC',
    designation: 'Sales Executive (SMPL)',
    role: 'EMPLOYEE',
    status: 'ACTIVE', // Explicitly activated by Super Admin
    mustChangePassword: false,
    credentialsProvisioned: true,
    createdAt: '2026-10-01T00:00:00.000Z',
    updatedAt: '2026-10-01T00:00:00.000Z',
  };

  const buf = await buildSampleTemplateWorkbook(
    '2026-11-18',
    [
      {
        branchName: 'BARAMATI MIDC',
        salesPersonName: 'SMPL BARAMATI',
        salesmanNo: '809',
        component1: 86,
        component2: 31,
        component3: 29,
      },
      {
        branchName: 'BEED',
        salesPersonName: 'beed smpl',
        salesmanNo: '2292', // New unregistered SMPL candidate
        component1: 106,
        component2: 0,
        component3: 15,
      },
    ],
    '2026-11-18',
  );

  const parsed = await parseExcelBuffer(buf, 'smpl-check.xlsx');
  const val = validateImportBatch({
    periodStart: parsed.periodStart,
    periodEnd: parsed.periodEnd,
    rawBannerDateText: parsed.reportDateRangeText,
    rawTotalRows: parsed.rawTotalRows,
    skippedBlankRows: parsed.skippedBlankRows,
    skippedSummaryRows: parsed.skippedSummaryRows,
    rows: parsed.rows,
    mapping: parsed.suggestedMapping,
    branches: BRANCHES,
    employees: [...EMPLOYEES, activeSmplEmployee],
    publishedIncentives: [],
  });

  assert.equal(val.metrics.smplCandidates, 2);
  // Active SMPL employee (809) remains VALID & ACTIVE (never auto-deactivated!)
  const row809 = val.rows.find((r) => r.employeeId === '809')!;
  assert.equal(row809.isSmplCandidate, true);
  assert.equal(row809.validationStatus, 'VALID');
  assert.equal(activeSmplEmployee.status, 'ACTIVE');

  // New SMPL candidate (2292) is surfaced for Super Admin explicit decision
  const cand2292 = val.newEmployeeCandidates.find((c) => c.salesmanNo === '2292')!;
  assert.equal(cand2292.isSmplCandidate, true);

  // Automated system import is strictly forbidden from changing status
  const sysAttempt = authorizeEmployeeStatusChange({
    actorRole: 'SYSTEM_IMPORT',
    currentStatus: 'ACTIVE',
    targetStatus: 'INACTIVE',
  });
  assert.equal(sysAttempt.allowed, false);
  assert.equal(sysAttempt.statusCode, 403);
});

// =========================================================================
// TEST 17: Published Record Correction Preserves Immutable Version History
// =========================================================================
test('17. Correction of published record requires reason, archives prior version, and increments version', () => {
  const existing = makePublishedRecord({
    importType: 'MONTHLY',
    periodStart: '2026-10-01',
    periodEnd: '2026-10-31',
    employeeId: '459',
    component1Paise: 100000,
    component2Paise: 5000,
    component3Paise: 5000,
    version: 1,
  });

  assert.throws(
    () =>
      applyPublishedCorrection({
        existingRecord: existing,
        newComponent1Paise: 110000,
        newComponent2Paise: 5000,
        newComponent3Paise: 5000,
        correctionReason: 'ok', // Too short (<4 chars)
        batchId: 'BATCH_CORR_1',
        actorEmail: 'uhvishal41@gmail.com',
        now: '2026-11-19T00:00:00.000Z',
      }),
    /mandatory correction reason/i,
  );

  const { updatedRecord, versionSnapshot } = applyPublishedCorrection({
    existingRecord: existing,
    newComponent1Paise: 110000,
    newComponent2Paise: 5000,
    newComponent3Paise: 5000,
    correctionReason: 'Revised ERP return credit adjustment',
    batchId: 'BATCH_CORR_1',
    actorEmail: 'uhvishal41@gmail.com',
    now: '2026-11-19T00:00:00.000Z',
  });

  assert.equal(versionSnapshot.previousVersion, 1);
  assert.equal(versionSnapshot.newVersion, 2);
  assert.equal(versionSnapshot.previousTotalPaise, 110000);
  assert.equal(versionSnapshot.newTotalPaise, 120000);
  assert.equal(updatedRecord.version, 2);
  assert.equal(updatedRecord.totalPaise, 120000);
  assert.equal(updatedRecord.importType, 'MONTHLY');
});

// =========================================================================
// TEST 18: Backend RBAC — Only SUPER_ADMIN Can Change Employee Status (403 for Branch Manager & Employee)
// =========================================================================
test('18. Backend API enforces SUPER_ADMIN-only employee status control (403 for BRANCH_MANAGER and EMPLOYEE)', async () => {
  const testAuthMiddleware = (
    req: AuthenticatedRequest,
    res: Response,
    next: NextFunction,
  ) => {
    const roleHeader = req.headers['x-test-role'] as UserRole | undefined;
    if (!roleHeader) {
      res.status(401).json({ error: 'Unauthenticated' });
      return;
    }
    req.authUser = {
      uid: `uid-${roleHeader.toLowerCase()}`,
      email:
        roleHeader === 'SUPER_ADMIN'
          ? 'uhvishal41@gmail.com'
          : `${roleHeader.toLowerCase()}@homfash.com`,
      emailVerified: true,
      role: roleHeader,
      isSuperAdmin: roleHeader === 'SUPER_ADMIN',
    };
    next();
  };

  const app = createExpressApp(testAuthMiddleware as never);
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const port = typeof address === 'object' && address ? address.port : 0;

  try {
    const callStatusEndpoint = async (role: UserRole | null, targetStatus: 'ACTIVE' | 'INACTIVE') => {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (role) headers['x-test-role'] = role;
      const resp = await fetch(
        `http://127.0.0.1:${port}/api/v1/admin/employees/authorize-status-change`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            employeeId: '459',
            currentStatus: 'ACTIVE',
            targetStatus,
          }),
        },
      );
      return { status: resp.status, body: await resp.json() };
    };

    const unauth = await callStatusEndpoint(null, 'INACTIVE');
    assert.equal(unauth.status, 401);

    const empAttempt = await callStatusEndpoint('EMPLOYEE', 'INACTIVE');
    assert.equal(empAttempt.status, 403);

    const bmAttempt = await callStatusEndpoint('BRANCH_MANAGER', 'INACTIVE');
    assert.equal(bmAttempt.status, 403);

    const adminAttempt = await callStatusEndpoint('SUPER_ADMIN', 'INACTIVE');
    assert.equal(adminAttempt.status, 200);
    assert.equal(adminAttempt.body.authorized, true);
    assert.equal(adminAttempt.body.auditAction, 'EMPLOYEE_DEACTIVATED');
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

// =========================================================================
// TEST 19: Deactivated Employee Blocked From Login While Preserving History
// =========================================================================
test('19. Deactivated employee is blocked from Employee Portal login while employee & historical incentives remain intact', () => {
  const inactiveEmp = EMPLOYEES.find((e) => e.employeeId === '2432')!;
  assert.equal(inactiveEmp.status, 'INACTIVE');

  const gate = canEmployeeLogin(inactiveEmp);
  assert.equal(gate.allowed, false);
  assert.equal(gate.code, 'ACCOUNT_DEACTIVATED');

  // Historical records for employee 2432 remain preserved in store
  const historicalRecords = [
    makePublishedRecord({
      employeeId: '2432',
      authUid: 'uid-emp-2432',
      importType: 'MONTHLY',
      periodStart: '2026-09-01',
      periodEnd: '2026-09-30',
      component1Paise: 98400,
      component2Paise: 500,
      component3Paise: 3200,
    }),
  ];
  const agg = aggregateEmployeeMonth(historicalRecords, '2432', '2026-09');
  assert.equal(agg.grandTotalPaise, 102100);
});

// =========================================================================
// TEST 20: Reactivated Employee Regains Full Access & Historical Data + Strict Isolation
// =========================================================================
test('20. Reactivated employee regains login access with all historical Daily/Monthly/Custom records intact and isolated', () => {
  const empRecord: Employee = { ...EMPLOYEES.find((e) => e.employeeId === '2432')! };

  // Super Admin authorizes reactivation
  const decision = authorizeEmployeeStatusChange({
    actorRole: 'SUPER_ADMIN',
    currentStatus: empRecord.status,
    targetStatus: 'ACTIVE',
  });
  assert.equal(decision.allowed, true);
  assert.equal(decision.auditAction, 'EMPLOYEE_REACTIVATED');

  empRecord.status = 'ACTIVE';
  const gateAfter = canEmployeeLogin(empRecord);
  assert.equal(gateAfter.allowed, true);
  assert.equal(gateAfter.code, 'OK');

  // Employee sees ONLY their own published incentives (strict isolation from employee 459)
  const mixedStore: PublishedIncentive[] = [
    makePublishedRecord({
      employeeId: '2432',
      authUid: 'uid-emp-2432',
      importType: 'MONTHLY',
      periodStart: '2026-09-01',
      periodEnd: '2026-09-30',
      component1Paise: 98400,
      component2Paise: 500,
      component3Paise: 3200,
    }),
    makePublishedRecord({
      employeeId: '2432',
      authUid: 'uid-emp-2432',
      importType: 'CUSTOM_PERIOD',
      periodStart: '2026-10-01',
      periodEnd: '2026-10-15',
      component1Paise: 45000,
      component2Paise: 1000,
      component3Paise: 1500,
    }),
    makePublishedRecord({
      employeeId: '459',
      authUid: 'uid-emp-459',
      importType: 'DAILY',
      periodStart: '2026-11-18',
      periodEnd: '2026-11-18',
      component1Paise: 81600,
      component2Paise: 1200,
      component3Paise: 5100,
    }),
  ];

  const ownScoped = mixedStore.filter((r) => r.authUid === empRecord.authUid);
  assert.equal(ownScoped.length, 2);
  assert.equal(ownScoped.some((r) => r.employeeId === '459'), false);

  const parts = partitionEmployeeRecords(ownScoped);
  assert.equal(parts.monthlyRecords.length, 1);
  assert.equal(parts.customPeriodRecords.length, 1);
  assert.equal(parts.dailyRecords.length, 0);
});
